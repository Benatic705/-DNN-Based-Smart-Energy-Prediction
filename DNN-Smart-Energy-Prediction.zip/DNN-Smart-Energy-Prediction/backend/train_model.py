"""Train, evaluate and save the DNN energy-prediction model.

Pipeline
  hourly_energy.csv -> features (lags, rolling stats, calendar) -> chronological
  70/15/15 split -> StandardScaler fitted on TRAIN only -> Keras DNN ->
  early stopping on validation loss -> evaluation on the untouched test set.

Outputs (backend/models/): energy_dnn.keras, scaler.joblib, metrics.json,
test_predictions.csv.

Usage: python train_model.py [--epochs 60] [--batch-size 128] [--seed 42]
"""
import argparse
import json
import os
import sys
import time

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")

import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

import config
from services.features import FEATURE_COLUMNS, MIN_HISTORY, build_feature_frame, recursive_forecast


def mae(a, b):
    return float(np.mean(np.abs(np.asarray(a) - np.asarray(b))))


def rmse(a, b):
    return float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))


def build_model(n_features: int):
    from tensorflow import keras

    model = keras.Sequential(
        [
            keras.layers.Input(shape=(n_features,)),
            keras.layers.Dense(128, activation="relu"),
            keras.layers.Dropout(0.2),
            keras.layers.Dense(64, activation="relu"),
            keras.layers.Dropout(0.1),
            keras.layers.Dense(32, activation="relu"),
            keras.layers.Dense(1),
        ],
        name="energy_dnn",
    )
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss="mse", metrics=["mae"])
    return model


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--batch-size", type=int, default=128)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    if not config.HOURLY_FILE.exists():
        print(f"ERROR: {config.HOURLY_FILE} not found.")
        print("Run: python download_dataset.py   then   python preprocess_data.py")
        return 1

    import tensorflow as tf
    from tensorflow import keras

    np.random.seed(args.seed)
    tf.keras.utils.set_random_seed(args.seed)

    series = pd.read_csv(config.HOURLY_FILE, parse_dates=["timestamp"], index_col="timestamp")["energy_kwh"].asfreq("h")
    X_all = build_feature_frame(series)
    data = X_all.assign(target=series).dropna()
    if len(data) < 2000:
        print(f"ERROR: only {len(data)} usable rows; need at least 2000 hours of data.")
        return 1

    n = len(data)
    i_tr, i_va = int(n * 0.70), int(n * 0.85)
    train, val, test = data.iloc[:i_tr], data.iloc[i_tr:i_va], data.iloc[i_va:]
    print(f"Rows  train={len(train):,}  val={len(val):,}  test={len(test):,}")
    print(f"Train {train.index.min()} -> {train.index.max()}")
    print(f"Val   {val.index.min()} -> {val.index.max()}")
    print(f"Test  {test.index.min()} -> {test.index.max()}")

    scaler = StandardScaler().fit(train[FEATURE_COLUMNS].to_numpy())  # train only: no leakage
    xs = {k: scaler.transform(d[FEATURE_COLUMNS].to_numpy()) for k, d in [("train", train), ("val", val), ("test", test)]}

    model = build_model(len(FEATURE_COLUMNS))
    model.summary()
    callbacks = [
        keras.callbacks.EarlyStopping(monitor="val_loss", patience=8, restore_best_weights=True),
        keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=3, min_lr=1e-5),
    ]
    t0 = time.time()
    hist = model.fit(
        xs["train"], train["target"].to_numpy(),
        validation_data=(xs["val"], val["target"].to_numpy()),
        epochs=args.epochs, batch_size=args.batch_size, callbacks=callbacks, verbose=2,
    )
    train_seconds = time.time() - t0

    # ---- evaluation on the held-out chronological test set ----
    pred_test = np.clip(model.predict(xs["test"], verbose=0).ravel(), 0, None)
    pred_val = np.clip(model.predict(xs["val"], verbose=0).ravel(), 0, None)
    y_test, y_val = test["target"].to_numpy(), val["target"].to_numpy()

    baselines = {
        "persistence_last_hour": {"mae": mae(y_test, test["lag_1"]), "rmse": rmse(y_test, test["lag_1"])},
        "seasonal_naive_24h": {"mae": mae(y_test, test["lag_24"]), "rmse": rmse(y_test, test["lag_24"])},
        "train_mean": {"mae": mae(y_test, np.full_like(y_test, train["target"].mean())),
                       "rmse": rmse(y_test, np.full_like(y_test, train["target"].mean()))},
    }

    # 24-hour recursive forecast quality on evenly spaced origins inside the test set
    def predict_rows(rows):
        return np.clip(model.predict(scaler.transform(rows[FEATURE_COLUMNS].to_numpy()), verbose=0).ravel(), 0, None)

    errs = []
    test_idx = series.index[(series.index >= test.index.min())]
    origins = np.linspace(MIN_HISTORY + 24, max(MIN_HISTORY + 24, len(test_idx) - 25), 20).astype(int)
    for o in origins:
        origin_ts = test_idx[o]
        hist_s = series.loc[:origin_ts]
        actual = series.loc[origin_ts + pd.Timedelta(hours=1): origin_ts + pd.Timedelta(hours=24)]
        if len(actual) < 24 or actual.isna().any() or hist_s.tail(MIN_HISTORY).isna().any():
            continue
        fc = recursive_forecast(predict_rows, hist_s, 24)
        errs.append((actual.to_numpy(), fc.to_numpy()))
    if errs:
        a = np.concatenate([e[0] for e in errs]); p = np.concatenate([e[1] for e in errs])
        multi = {"origins_evaluated": len(errs), "mae": mae(a, p), "rmse": rmse(a, p)}
    else:
        multi = {"origins_evaluated": 0, "mae": None, "rmse": None}

    metrics = {
        "trained_at": pd.Timestamp.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "tensorflow_version": tf.__version__,
        "unit": "kWh per hour",
        "features": FEATURE_COLUMNS,
        "architecture": "Dense(128,relu)-Dropout(0.2)-Dense(64,relu)-Dropout(0.1)-Dense(32,relu)-Dense(1)",
        "split": {
            "method": "chronological 70/15/15 (no shuffling)",
            "train": {"rows": len(train), "start": str(train.index.min()), "end": str(train.index.max())},
            "validation": {"rows": len(val), "start": str(val.index.min()), "end": str(val.index.max())},
            "test": {"rows": len(test), "start": str(test.index.min()), "end": str(test.index.max())},
        },
        "training": {
            "epochs_run": len(hist.history["loss"]),
            "epochs_max": args.epochs,
            "batch_size": args.batch_size,
            "seed": args.seed,
            "seconds": round(train_seconds, 1),
            "final_train_loss": float(hist.history["loss"][-1]),
            "best_val_loss": float(min(hist.history["val_loss"])),
        },
        "validation": {"mae": mae(y_val, pred_val), "rmse": rmse(y_val, pred_val)},
        "test": {"mae": mae(y_test, pred_test), "rmse": rmse(y_test, pred_test), "one_step_ahead": True},
        "test_24h_recursive": multi,
        "baselines_on_test": baselines,
        "loss_history": {"loss": [float(x) for x in hist.history["loss"]], "val_loss": [float(x) for x in hist.history["val_loss"]]},
    }

    config.MODELS_DIR.mkdir(parents=True, exist_ok=True)
    model.save(config.MODEL_FILE)
    joblib.dump(scaler, config.SCALER_FILE)
    with open(config.METRICS_FILE, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    pd.DataFrame({"actual_kwh": y_test, "predicted_kwh": pred_test}, index=test.index).rename_axis("timestamp").to_csv(config.TEST_PRED_FILE)

    print("\n=== Test set (held-out, one-step-ahead) ===")
    print(f"MAE  : {metrics['test']['mae']:.4f} kWh")
    print(f"RMSE : {metrics['test']['rmse']:.4f} kWh")
    print(f"Baseline persistence MAE/RMSE : {baselines['persistence_last_hour']['mae']:.4f} / {baselines['persistence_last_hour']['rmse']:.4f}")
    print(f"Baseline seasonal-24h MAE/RMSE: {baselines['seasonal_naive_24h']['mae']:.4f} / {baselines['seasonal_naive_24h']['rmse']:.4f}")
    if multi["mae"] is not None:
        print(f"24h recursive forecast MAE/RMSE ({multi['origins_evaluated']} origins): {multi['mae']:.4f} / {multi['rmse']:.4f}")
    print(f"\nSaved: {config.MODEL_FILE}\n       {config.SCALER_FILE}\n       {config.METRICS_FILE}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
