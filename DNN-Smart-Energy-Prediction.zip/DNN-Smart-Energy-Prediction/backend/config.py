"""Central configuration: file paths and constants.

Paths can be overridden with environment variables (used by the tests):
    ENERGY_DATA_DIR, ENERGY_MODELS_DIR
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("ENERGY_DATA_DIR", BASE_DIR / "data"))
MODELS_DIR = Path(os.environ.get("ENERGY_MODELS_DIR", BASE_DIR / "models"))

RAW_FILE = DATA_DIR / "household_power_consumption.txt"
HOURLY_FILE = DATA_DIR / "hourly_energy.csv"

MODEL_FILE = MODELS_DIR / "energy_dnn.keras"
SCALER_FILE = MODELS_DIR / "scaler.joblib"
METRICS_FILE = MODELS_DIR / "metrics.json"
TEST_PRED_FILE = MODELS_DIR / "test_predictions.csv"

UCI_ZIP_URL = (
    "https://archive.ics.uci.edu/static/public/235/"
    "individual+household+electric+power+consumption.zip"
)
UCI_PAGE = "https://archive.ics.uci.edu/dataset/235/individual+household+electric+power+consumption"

DEFAULT_RATE_INR_PER_KWH = 8.0
MAX_RATE_INR_PER_KWH = 100.0

# Hours of consecutive gaps that preprocessing will linearly interpolate.
MAX_INTERPOLATE_HOURS = 6
# Minimum valid minute readings (out of 60) required to accept an hourly value.
MIN_VALID_MINUTES = 30
