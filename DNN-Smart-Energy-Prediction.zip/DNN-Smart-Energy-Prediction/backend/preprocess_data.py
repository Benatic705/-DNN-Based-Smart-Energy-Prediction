"""Convert the raw UCI minute-level file into a clean hourly energy series.

Steps
1. Read semicolon-separated file; '?' marks missing values -> NaN.
2. Parse Date (dd/mm/yyyy) + Time into one timestamp; coerce bad rows to NaN.
3. Treat Global_active_power < 0 as invalid.
4. Aggregate to hourly: energy_kwh = mean kW over valid minutes (x 1 hour).
   An hour needs at least MIN_VALID_MINUTES valid minutes, otherwise it is missing.
5. Reindex to a regular hourly grid. Gaps up to MAX_INTERPOLATE_HOURS are linearly
   interpolated (flagged in `interpolated`); longer gaps stay NaN and are never
   used for training or statistics.

Output: data/hourly_energy.csv with columns timestamp, energy_kwh, interpolated.

Usage: python preprocess_data.py
"""
import sys

import numpy as np
import pandas as pd

from config import HOURLY_FILE, MAX_INTERPOLATE_HOURS, MIN_VALID_MINUTES, RAW_FILE


def preprocess(raw_path=RAW_FILE, out_path=HOURLY_FILE, verbose=True) -> pd.DataFrame:
    df = pd.read_csv(
        raw_path,
        sep=";",
        na_values=["?", ""],
        usecols=["Date", "Time", "Global_active_power"],
        dtype={"Date": str, "Time": str},
        low_memory=False,
    )
    n_raw = len(df)
    df["timestamp"] = pd.to_datetime(
        df["Date"] + " " + df["Time"], format="%d/%m/%Y %H:%M:%S", errors="coerce"
    )
    df["kw"] = pd.to_numeric(df["Global_active_power"], errors="coerce")
    n_bad_ts = int(df["timestamp"].isna().sum())
    df = df.dropna(subset=["timestamp"])
    invalid = df["kw"] < 0
    n_invalid = int(invalid.sum())
    df.loc[invalid, "kw"] = np.nan
    n_missing_minutes = int(df["kw"].isna().sum())

    df = df.drop_duplicates(subset="timestamp").set_index("timestamp").sort_index()
    grouped = df["kw"].resample("h")
    mean_kw = grouped.mean()
    valid_minutes = grouped.count()
    hourly = mean_kw.where(valid_minutes >= MIN_VALID_MINUTES)  # kW*1h = kWh
    hourly = hourly.asfreq("h")

    missing_before = hourly.isna()
    filled = hourly.interpolate(method="time", limit=MAX_INTERPOLATE_HOURS, limit_area="inside")
    interpolated = missing_before & filled.notna()

    out = pd.DataFrame(
        {"energy_kwh": filled.round(4), "interpolated": interpolated.astype(int)}
    )
    out.index.name = "timestamp"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(out_path)

    if verbose:
        print(f"Raw rows:                 {n_raw:,}")
        print(f"Unparseable timestamps:   {n_bad_ts:,}")
        print(f"Negative (invalid) kW:    {n_invalid:,}")
        print(f"Missing minute readings:  {n_missing_minutes:,}")
        print(f"Hourly rows:              {len(out):,}  ({out.index.min()} -> {out.index.max()})")
        print(f"Hours interpolated:       {int(interpolated.sum()):,}")
        print(f"Hours still missing:      {int(out['energy_kwh'].isna().sum()):,}")
        print(f"Saved: {out_path}")
    return out


if __name__ == "__main__":
    if not RAW_FILE.exists():
        print(f"ERROR: raw dataset not found at {RAW_FILE}")
        print("Run:  python download_dataset.py   (or see README for manual download)")
        sys.exit(1)
    preprocess()
