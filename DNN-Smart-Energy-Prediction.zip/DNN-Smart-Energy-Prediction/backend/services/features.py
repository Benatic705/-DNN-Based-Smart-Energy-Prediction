"""Feature engineering shared by training and inference.

Every feature for target hour T uses only information from hours < T
(lags, rolling stats on shifted data) plus calendar features of T itself,
so there is no target leakage.
"""
import numpy as np
import pandas as pd

LAGS = [1, 2, 3, 24, 48, 168]
MIN_HISTORY = 169  # hours of history needed before a row has all features

FEATURE_COLUMNS = (
    [f"lag_{k}" for k in LAGS]
    + ["roll_mean_24", "roll_std_24", "roll_mean_168"]
    + ["hour_sin", "hour_cos", "dow_sin", "dow_cos", "month_sin", "month_cos", "is_weekend"]
)


def build_feature_frame(series: pd.Series) -> pd.DataFrame:
    """Feature matrix for every timestamp of a regular hourly series (kWh)."""
    s = series.astype(float)
    df = pd.DataFrame(index=s.index)
    for k in LAGS:
        df[f"lag_{k}"] = s.shift(k)
    prev = s.shift(1)
    df["roll_mean_24"] = prev.rolling(24).mean()
    df["roll_std_24"] = prev.rolling(24).std()
    df["roll_mean_168"] = prev.rolling(168).mean()

    idx = s.index
    hour, dow, month = idx.hour.to_numpy(), idx.dayofweek.to_numpy(), idx.month.to_numpy()
    df["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    df["hour_cos"] = np.cos(2 * np.pi * hour / 24)
    df["dow_sin"] = np.sin(2 * np.pi * dow / 7)
    df["dow_cos"] = np.cos(2 * np.pi * dow / 7)
    df["month_sin"] = np.sin(2 * np.pi * (month - 1) / 12)
    df["month_cos"] = np.cos(2 * np.pi * (month - 1) / 12)
    df["is_weekend"] = (dow >= 5).astype(int)
    return df[FEATURE_COLUMNS]


def next_row_features(history: pd.Series) -> pd.DataFrame:
    """Features for the hour right after the last timestamp of `history`."""
    tail = history.tail(MIN_HISTORY + 24).astype(float).copy()
    next_ts = tail.index[-1] + pd.Timedelta(hours=1)
    tail.loc[next_ts] = np.nan
    row = build_feature_frame(tail).iloc[[-1]]
    if row.isna().any(axis=None):
        raise ValueError(
            f"Not enough contiguous valid history: need the last {MIN_HISTORY} hours "
            "without gaps to forecast."
        )
    return row


def recursive_forecast(predict_fn, history: pd.Series, steps: int) -> pd.Series:
    """Forecast `steps` hours ahead; each prediction is fed back as history.

    predict_fn: callable(DataFrame of feature rows) -> array of kWh.
    """
    s = history.tail(MIN_HISTORY + 24).astype(float).copy()
    preds = {}
    for _ in range(steps):
        row = next_row_features(s)
        ts = row.index[0]
        value = float(max(0.0, np.asarray(predict_fn(row)).ravel()[0]))
        s.loc[ts] = value
        preds[ts] = value
    return pd.Series(preds, name="predicted_kwh")
