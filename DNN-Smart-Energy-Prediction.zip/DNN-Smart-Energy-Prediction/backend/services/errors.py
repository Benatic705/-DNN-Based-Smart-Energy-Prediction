class ServiceError(Exception):
    """Error that maps to a clean JSON response: {"error": ..., "hint": ...}."""

    def __init__(self, message: str, hint: str = "", status_code: int = 503):
        super().__init__(message)
        self.message = message
        self.hint = hint
        self.status_code = status_code


class DatasetMissing(ServiceError):
    def __init__(self):
        super().__init__(
            "Hourly dataset not found.",
            "From the backend folder run: python download_dataset.py  then  python preprocess_data.py",
            503,
        )


class ModelMissing(ServiceError):
    def __init__(self):
        super().__init__(
            "Trained model not found.",
            "From the backend folder run: python train_model.py",
            503,
        )
