"""Anomaly detection: robust z-score against a per-(hour-of-day, weekday/weekend) baseline.

Method
  For each group (hour of day x weekday/weekend) compute the median and the
  MAD (median absolute deviation, scaled by 1.4826 to be comparable to a std).
  robust_z = (value - median) / MAD_scaled. Readings with robust_z > threshold
  are flagged as *unusually high*.
  The baseline is fitted on data BEFORE the inspected window (when there is
  enough of it), so the window does not contaminate its own baseline.

Limitations (also returned by the API)
  - A flag means "statistically unusual for that hour", not a confirmed fault.
    Holidays, guests, heating/cooling spells or new appliances produce flags too.
  - Seasonal drift is not modelled; a hot summer can raise many readings.
  - Only high readings are flagged; abnormally low use (e.g. outage) is ignored.
  - The baseline is a single household's history; the threshold is a tunable
    trade-off between false alarms and missed events.
"""
import numpy as np
import pandas as pd

from services import data_service
from services.errors import ServiceError

LIMITATIONS = [
    "A flag means 'unusually high compared with similar hours', not a confirmed fault or appliance failure.",
    "Holidays, guests, weather spells and new appliances can all trigger flags.",
    "Seasonal drift is not modelled, so a long hot or cold period can raise many readings.",
    "Only unusually HIGH consumption is flagged; unusually low usage (e.g. power cuts) is not.",
    "Lowering the threshold finds more events but also more false alarms.",
]

MAD_SCALE = 1.4826
MIN_BASELINE_HOURS = 24 * 14


def _groups(index: pd.DatetimeIndex) -> pd.Series:
    return pd.Series(
        (index.hour.to_numpy() + 24 * (index.dayofweek.to_numpy() >= 5)), index=index
    )


def _fit_baseline(s: pd.Series) -> pd.DataFrame:
    g = _groups(s.index)
    df = pd.DataFrame({"v": s.to_numpy(), "g": g.to_numpy()}).dropna()
    med = df.groupby("g")["v"].median()
    mad = df.assign(med=df["g"].map(med)).assign(d=lambda x: (x["v"] - x["med"]).abs()).groupby("g")["d"].median()
    scaled = (mad * MAD_SCALE).clip(lower=0.05)  # floor avoids division by ~0
    return pd.DataFrame({"median": med, "scale": scaled})


def detect(series: pd.Series, days: int = 30, threshold: float = 3.5) -> dict:
    if threshold <= 0:
        raise ServiceError("threshold must be positive.", "", 422)
    end = series.index.max()
    start = end - pd.Timedelta(days=days)
    window = series[series.index > start]
    before = series[series.index <= start].dropna()
    base_src = before if len(before) >= MIN_BASELINE_HOURS else series.dropna()
    if len(base_src) < MIN_BASELINE_HOURS:
        raise ServiceError(
            "Not enough history to build a baseline (need at least 14 days of valid data).", "", 422
        )
    base = _fit_baseline(base_src)

    g = _groups(window.index)
    med = g.map(base["median"]).to_numpy(dtype=float)
    scale = g.map(base["scale"]).to_numpy(dtype=float)
    vals = window.to_numpy(dtype=float)
    z = (vals - med) / scale
    flagged = np.where(np.isnan(vals), False, z > threshold)
    upper = med + threshold * scale

    anomalies, chart = [], []
    for i, ts in enumerate(window.index):
        v = None if np.isnan(vals[i]) else round(float(vals[i]), 4)
        chart.append(
            {
                "timestamp": ts.strftime("%Y-%m-%dT%H:%M:%S"),
                "energy_kwh": v,
                "expected_kwh": round(float(med[i]), 4),
                "upper_limit_kwh": round(float(upper[i]), 4),
                "anomaly_kwh": v if flagged[i] else None,
            }
        )
        if flagged[i]:
            anomalies.append(
                {
                    "timestamp": ts.strftime("%Y-%m-%dT%H:%M:%S"),
                    "energy_kwh": v,
                    "expected_kwh": round(float(med[i]), 4),
                    "robust_z": round(float(z[i]), 2),
                    "severity": "high" if z[i] >= 2 * threshold else "moderate",
                }
            )
    anomalies.sort(key=lambda a: a["timestamp"], reverse=True)
    valid = int(np.sum(~np.isnan(vals)))
    return {
        "method": "Robust z-score (median/MAD) per hour-of-day and weekday/weekend group",
        "threshold": threshold,
        "days": days,
        "window_start": window.index.min().strftime("%Y-%m-%dT%H:%M:%S"),
        "window_end": window.index.max().strftime("%Y-%m-%dT%H:%M:%S"),
        "valid_hours": valid,
        "anomaly_count": len(anomalies),
        "anomaly_rate_pct": round(100.0 * len(anomalies) / valid, 2) if valid else 0.0,
        "anomalies": anomalies[:200],
        "chart": chart,
        "limitations": LIMITATIONS,
    }


def detect_from_dataset(days: int = 30, threshold: float = 3.5) -> dict:
    return detect(data_service.load_hourly(), days, threshold)
