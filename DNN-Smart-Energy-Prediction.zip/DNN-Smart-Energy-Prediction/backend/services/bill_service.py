"""Simple electricity bill estimation: energy (kWh) x rate (INR per kWh)."""
import config
from services import data_service, model_service
from services.errors import ServiceError

DISCLAIMER = (
    "Estimate = kWh x flat rate. It excludes tariff slabs, fixed/demand charges, "
    "fuel surcharges, taxes and other charges your distribution company may apply."
)


def validate_rate(rate: float) -> float:
    if not (0 < rate <= config.MAX_RATE_INR_PER_KWH):
        raise ServiceError(
            f"rate must be greater than 0 and at most {config.MAX_RATE_INR_PER_KWH} INR/kWh.", "", 422
        )
    return float(rate)


def cost(kwh: float, rate: float) -> float:
    return round(float(kwh) * rate, 2)


def estimate(source: str = "actual", days: int = 30, rate: float = config.DEFAULT_RATE_INR_PER_KWH) -> dict:
    rate = validate_rate(rate)
    if source == "actual":
        stats = data_service.recent_stats(days)
        total = stats["total_kwh"]
        return {
            "source": "actual",
            "period": {"start": stats["start"], "end": stats["end"], "days": days},
            "rate_inr_per_kwh": rate,
            "energy_kwh": total,
            "estimated_cost_inr": cost(total, rate),
            "avg_daily_cost_inr": cost(stats["avg_daily_kwh"], rate),
            "projected_30_day_cost_inr": cost(stats["avg_daily_kwh"] * 30, rate),
            "valid_hours": stats["valid_hours"],
            "disclaimer": DISCLAIMER,
        }
    if source == "forecast":
        fc = model_service.forecast(24)
        total = fc["total_kwh"]
        return {
            "source": "forecast",
            "period": {
                "start": fc["predictions"][0]["timestamp"],
                "end": fc["predictions"][-1]["timestamp"],
                "days": 1,
            },
            "rate_inr_per_kwh": rate,
            "energy_kwh": total,
            "estimated_cost_inr": cost(total, rate),
            "avg_daily_cost_inr": cost(total, rate),
            "projected_30_day_cost_inr": cost(total * 30, rate),
            "valid_hours": 24,
            "disclaimer": DISCLAIMER,
        }
    raise ServiceError("source must be 'actual' or 'forecast'.", "", 422)
