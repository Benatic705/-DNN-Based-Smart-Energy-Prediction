"""Rule-based energy-saving recommendations derived from the actual data.

No savings are promised: each tip shows the evidence (numbers computed from the
dataset) and, where useful, what the pattern costs at the chosen rate.
"""
import pandas as pd

import config
from services import anomaly_service, data_service, model_service
from services.errors import ServiceError


def _fmt_hour(h: int) -> str:
    return f"{h:02d}:00-{(h + 1) % 24:02d}:00"


def build(rate: float = config.DEFAULT_RATE_INR_PER_KWH, window_days: int = 90) -> dict:
    s = data_service.load_hourly()
    w = s[s.index > s.index.max() - pd.Timedelta(days=window_days)].dropna()
    if len(w) < 24 * 7:
        raise ServiceError("Need at least 7 days of valid data for recommendations.", "", 422)

    recs = []
    by_hour = w.groupby(w.index.hour).mean()

    # 1. Always-on base load
    night = by_hour.loc[[1, 2, 3, 4, 5]].mean()
    monthly_cost = night * 24 * 30 * rate
    recs.append(
        {
            "id": "base-load",
            "category": "Standby / base load",
            "priority": "medium",
            "title": "Check always-on devices",
            "detail": (
                f"Between 01:00 and 06:00 the home still draws about {night:.2f} kWh per hour. "
                f"If that level ran all month it would cost about INR {monthly_cost:,.0f} at INR {rate:g}/kWh. "
                "Look for devices left on overnight (set-top boxes, chargers, old fridges, water heaters)."
            ),
            "evidence": {"overnight_avg_kwh_per_hour": round(float(night), 3), "monthly_cost_of_level_inr": round(float(monthly_cost))},
        }
    )

    # 2. Peak hours
    top3 = by_hour.sort_values(ascending=False).head(3)
    peak_hours = sorted(int(h) for h in top3.index)
    share = float(w[w.index.hour.isin(peak_hours)].sum() / w.sum() * 100)
    recs.append(
        {
            "id": "peak-hours",
            "category": "Load shifting",
            "priority": "high",
            "title": "Spread flexible loads away from your peak hours",
            "detail": (
                f"Your three busiest hours of the day are {', '.join(_fmt_hour(h) for h in peak_hours)}, "
                f"which account for {share:.0f}% of consumption over the last {window_days} days of data. "
                "Run flexible appliances (washing machine, dishwasher, water heating) outside these hours. "
                "This reduces peak load; savings in rupees depend on whether your tariff has time-of-day pricing."
            ),
            "evidence": {"peak_hours": peak_hours, "share_of_energy_pct": round(share, 1)},
        }
    )

    # 3. Weekend vs weekday
    wk = w[w.index.dayofweek < 5].groupby(w[w.index.dayofweek < 5].index.date).sum().mean()
    we = w[w.index.dayofweek >= 5].groupby(w[w.index.dayofweek >= 5].index.date).sum().mean()
    if pd.notna(wk) and pd.notna(we) and wk > 0:
        diff = (we - wk) / wk * 100
        recs.append(
            {
                "id": "weekend",
                "category": "Usage pattern",
                "priority": "low",
                "title": "Weekend vs weekday usage",
                "detail": (
                    f"Average daily use is {wk:.1f} kWh on weekdays and {we:.1f} kWh on weekends "
                    f"({diff:+.0f}%). "
                    + (
                        "Weekends are noticeably higher - plan heavy appliance use across the week."
                        if diff > 10
                        else "The difference is small, so there is no obvious weekend-specific habit to change."
                    )
                ),
                "evidence": {"weekday_avg_kwh": round(float(wk), 2), "weekend_avg_kwh": round(float(we), 2)},
            }
        )

    # 4. Anomalies
    try:
        an = anomaly_service.detect_from_dataset(days=30, threshold=3.5)
        n = an["anomaly_count"]
        recs.append(
            {
                "id": "anomalies",
                "category": "Anomalies",
                "priority": "high" if an["anomaly_rate_pct"] > 5 else "low",
                "title": "Review unusually high hours",
                "detail": (
                    f"{n} of the last {an['valid_hours']} valid hours ({an['anomaly_rate_pct']}%) were flagged as unusually high "
                    "(robust z-score above 3.5). Open the Anomalies page and check whether those hours match known events; "
                    "flags are not confirmed faults."
                ),
                "evidence": {"anomaly_count": n, "anomaly_rate_pct": an["anomaly_rate_pct"]},
            }
        )
    except ServiceError:
        pass

    # 5. Forecast-based tip (only if model exists)
    forecast_info = None
    if model_service.model_available():
        try:
            fc = model_service.forecast(24)
            pts = fc["predictions"]
            hi = max(pts, key=lambda p: p["predicted_kwh"])
            lo = min(pts, key=lambda p: p["predicted_kwh"])
            hi_h, lo_h = int(hi["timestamp"][11:13]), int(lo["timestamp"][11:13])
            forecast_info = {"highest": hi, "lowest": lo}
            recs.append(
                {
                    "id": "forecast",
                    "category": "AI forecast",
                    "priority": "medium",
                    "title": "Use the forecast to time heavy loads",
                    "detail": (
                        f"The DNN forecasts the next 24 hours to peak around {_fmt_hour(hi_h)} "
                        f"({hi['predicted_kwh']:.2f} kWh) and be lowest around {_fmt_hour(lo_h)} "
                        f"({lo['predicted_kwh']:.2f} kWh). Forecasts are estimates with error; see the metrics page."
                    ),
                    "evidence": {"peak_hour": hi_h, "lowest_hour": lo_h},
                }
            )
        except ServiceError:
            pass

    return {
        "rate_inr_per_kwh": rate,
        "based_on": f"last {window_days} days of the historical dataset",
        "method": "Rule-based analysis of real dataset records; no savings are guaranteed.",
        "recommendations": recs,
    }
