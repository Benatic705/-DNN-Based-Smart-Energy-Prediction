"""Reads the preprocessed hourly dataset and computes summaries."""
import pandas as pd

import config
from services.errors import DatasetMissing, ServiceError

_cache = {"mtime": None, "path": None, "series": None, "flags": None}


def _iso(ts) -> str:
    return pd.Timestamp(ts).strftime("%Y-%m-%dT%H:%M:%S")


def dataset_available() -> bool:
    return config.HOURLY_FILE.exists()


def load_hourly() -> pd.Series:
    """Hourly kWh series (NaN where unknown). Cached until the file changes."""
    path = config.HOURLY_FILE
    if not path.exists():
        raise DatasetMissing()
    mtime = path.stat().st_mtime
    if _cache["series"] is None or _cache["mtime"] != mtime or _cache["path"] != str(path):
        try:
            df = pd.read_csv(path, parse_dates=["timestamp"], index_col="timestamp")
        except Exception as exc:  # corrupt file
            raise ServiceError(f"Could not read hourly dataset: {exc}", "Re-run preprocess_data.py", 500)
        if "energy_kwh" not in df.columns or df.empty:
            raise ServiceError("Hourly dataset is empty or malformed.", "Re-run preprocess_data.py", 500)
        series = df["energy_kwh"].astype(float).asfreq("h")
        _cache.update(mtime=mtime, path=str(path), series=series)
    return _cache["series"]


def _window(series: pd.Series, days: int) -> pd.Series:
    end = series.index.max()
    return series[series.index > end - pd.Timedelta(days=days)]


def dataset_status() -> dict:
    if not dataset_available():
        return {
            "available": False,
            "message": "Hourly dataset not found.",
            "hint": "Run: python download_dataset.py  then  python preprocess_data.py",
            "source": config.UCI_PAGE,
        }
    s = load_hourly()
    valid = s.dropna()
    return {
        "available": True,
        "source": "UCI Individual Household Electric Power Consumption (real data, hourly aggregate)",
        "source_url": config.UCI_PAGE,
        "start": _iso(s.index.min()),
        "end": _iso(s.index.max()),
        "total_hours": int(len(s)),
        "valid_hours": int(len(valid)),
        "missing_hours": int(len(s) - len(valid)),
        "total_kwh": round(float(valid.sum()), 2),
        "avg_hourly_kwh": round(float(valid.mean()), 4),
        "max_hourly_kwh": round(float(valid.max()), 4),
        "min_hourly_kwh": round(float(valid.min()), 4),
    }


def recent_stats(days: int = 30) -> dict:
    s = load_hourly()
    w = _window(s, days).dropna()
    if w.empty:
        raise ServiceError("No valid readings in the requested window.", "", 404)
    daily = w.resample("D").sum()
    return {
        "days": days,
        "start": _iso(w.index.min()),
        "end": _iso(w.index.max()),
        "total_kwh": round(float(w.sum()), 2),
        "avg_hourly_kwh": round(float(w.mean()), 4),
        "avg_daily_kwh": round(float(daily.mean()), 2),
        "peak_hour_kwh": round(float(w.max()), 3),
        "peak_hour_at": _iso(w.idxmax()),
        "valid_hours": int(len(w)),
    }


def history(days: int = 7) -> list:
    s = _window(load_hourly(), days)
    return [
        {"timestamp": _iso(ts), "energy_kwh": None if pd.isna(v) else round(float(v), 4)}
        for ts, v in s.items()
    ]


def daily(days: int = 30) -> list:
    w = _window(load_hourly(), days)
    g = w.resample("D")
    total, hours = g.sum(min_count=1), g.count()
    return [
        {
            "date": ts.strftime("%Y-%m-%d"),
            "energy_kwh": None if pd.isna(total[ts]) else round(float(total[ts]), 3),
            "hours_covered": int(hours[ts]),
            "complete": bool(hours[ts] >= 22),
        }
        for ts in total.index
    ]


def monthly() -> list:
    s = load_hourly()
    g = s.resample("MS")
    total, hours = g.sum(min_count=1), g.count()
    expected = s.resample("MS").size()
    out = []
    for ts in total.index:
        if hours[ts] == 0:
            continue
        out.append(
            {
                "month": ts.strftime("%Y-%m"),
                "energy_kwh": round(float(total[ts]), 2),
                "hours_covered": int(hours[ts]),
                "coverage_pct": round(100.0 * hours[ts] / max(1, expected[ts]), 1),
            }
        )
    return out
