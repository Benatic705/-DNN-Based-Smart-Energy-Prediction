"""Loads the trained Keras DNN and produces real model predictions."""
import json
import os

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")

import numpy as np
import pandas as pd

import config
from services import data_service
from services.errors import ModelMissing, ServiceError
from services.features import FEATURE_COLUMNS, next_row_features, recursive_forecast

_state = {"mtime": None, "model": None, "scaler": None}


def model_available() -> bool:
    return config.MODEL_FILE.exists() and config.SCALER_FILE.exists()


def _load():
    if not model_available():
        raise ModelMissing()
    mtime = config.MODEL_FILE.stat().st_mtime
    if _state["model"] is None or _state["mtime"] != mtime:
        try:
            import joblib
            from tensorflow import keras

            _state["model"] = keras.models.load_model(str(config.MODEL_FILE), compile=False)
            _state["scaler"] = joblib.load(config.SCALER_FILE)
            _state["mtime"] = mtime
        except Exception as exc:
            raise ServiceError(
                f"Could not load the trained model: {exc}",
                "Re-run: python train_model.py (use the same TensorFlow version as in requirements.txt)",
                500,
            )
    return _state["model"], _state["scaler"]


def predict_rows(rows: pd.DataFrame) -> np.ndarray:
    model, scaler = _load()
    x = scaler.transform(rows[FEATURE_COLUMNS].to_numpy())
    return model.predict(x, verbose=0).ravel()


def _history_for_forecast() -> pd.Series:
    s = data_service.load_hourly()
    valid_end = s.last_valid_index()
    if valid_end is None:
        raise ServiceError("Dataset has no valid readings.", "", 500)
    return s.loc[:valid_end]


def next_hour() -> dict:
    hist = _history_for_forecast()
    try:
        row = next_row_features(hist)
    except ValueError as exc:
        raise ServiceError(str(exc), "Check dataset coverage at the end of the series.", 422)
    pred = float(max(0.0, predict_rows(row)[0]))
    return {
        "timestamp": row.index[0].strftime("%Y-%m-%dT%H:%M:%S"),
        "predicted_kwh": round(pred, 4),
        "based_on_data_until": hist.index[-1].strftime("%Y-%m-%dT%H:%M:%S"),
        "note": "Forecast for the hour after the last record in the historical dataset (not live data).",
    }


def forecast(hours: int = 24) -> dict:
    hist = _history_for_forecast()
    try:
        preds = recursive_forecast(predict_rows, hist, hours)
    except ValueError as exc:
        raise ServiceError(str(exc), "Check dataset coverage at the end of the series.", 422)
    points = [
        {"timestamp": ts.strftime("%Y-%m-%dT%H:%M:%S"), "predicted_kwh": round(float(v), 4)}
        for ts, v in preds.items()
    ]
    return {
        "hours": hours,
        "method": "Recursive multi-step forecast: each predicted hour is fed back as an input for the next.",
        "based_on_data_until": hist.index[-1].strftime("%Y-%m-%dT%H:%M:%S"),
        "total_kwh": round(float(preds.sum()), 3),
        "predictions": points,
    }


def metrics() -> dict:
    if not config.METRICS_FILE.exists():
        raise ModelMissing()
    with open(config.METRICS_FILE, encoding="utf-8") as f:
        return json.load(f)


def test_predictions(hours: int = 168) -> dict:
    if not config.TEST_PRED_FILE.exists():
        raise ModelMissing()
    df = pd.read_csv(config.TEST_PRED_FILE, parse_dates=["timestamp"])
    df = df.tail(hours)
    return {
        "hours": int(len(df)),
        "note": "Held-out chronological test set: the model never saw these hours during training or validation.",
        "points": [
            {
                "timestamp": r.timestamp.strftime("%Y-%m-%dT%H:%M:%S"),
                "actual_kwh": round(float(r.actual_kwh), 4),
                "predicted_kwh": round(float(r.predicted_kwh), 4),
            }
            for r in df.itertuples()
        ],
    }
