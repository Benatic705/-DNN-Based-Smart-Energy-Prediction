"""FastAPI backend for the DNN Smart Energy Prediction system.

Run (from backend/, venv active):  uvicorn main:app --reload --port 8000
Interactive docs: http://127.0.0.1:8000/docs
"""
from fastapi import FastAPI, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

import config
from services import (
    anomaly_service,
    bill_service,
    data_service,
    model_service,
    recommendation_service,
)
from services.errors import ServiceError

app = FastAPI(title="DNN Smart Energy Prediction API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:4173",
        "http://127.0.0.1:4173",
    ],
    allow_methods=["GET"],
    allow_headers=["*"],
)


@app.exception_handler(ServiceError)
async def service_error_handler(_: Request, exc: ServiceError):
    return JSONResponse(status_code=exc.status_code, content={"error": exc.message, "hint": exc.hint})


@app.exception_handler(RequestValidationError)
async def validation_handler(_: Request, exc: RequestValidationError):
    first = exc.errors()[0] if exc.errors() else {}
    field = ".".join(str(p) for p in first.get("loc", []) if p != "query")
    return JSONResponse(
        status_code=422,
        content={"error": f"Invalid input for '{field}': {first.get('msg', 'invalid value')}", "hint": "See /docs for allowed values."},
    )


@app.exception_handler(Exception)
async def unexpected_handler(_: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"error": f"Unexpected server error: {exc}", "hint": "Check the backend terminal for details."})


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "version": app.version,
        "dataset_available": data_service.dataset_available(),
        "model_available": model_service.model_available(),
    }


@app.get("/api/status")
def status():
    """Combined dataset + model status for the dashboard status indicators."""
    m = None
    if config.METRICS_FILE.exists():
        try:
            mm = model_service.metrics()
            m = {"trained_at": mm.get("trained_at"), "tensorflow_version": mm.get("tensorflow_version")}
        except Exception:
            m = None
    return {
        "dataset": data_service.dataset_status(),
        "model": {
            "available": model_service.model_available(),
            "info": m,
            "hint": None if model_service.model_available() else "Run: python train_model.py",
        },
    }


@app.get("/api/dataset/status")
def dataset_status():
    return data_service.dataset_status()


@app.get("/api/dataset/summary")
def dataset_summary(days: int = Query(30, ge=1, le=3650)):
    return {"overall": data_service.dataset_status(), "recent": data_service.recent_stats(days)}


@app.get("/api/energy/history")
def energy_history(days: int = Query(7, ge=1, le=60)):
    return {"days": days, "unit": "kWh per hour", "points": data_service.history(days)}


@app.get("/api/energy/daily")
def energy_daily(days: int = Query(30, ge=1, le=365)):
    return {"days": days, "unit": "kWh per day", "points": data_service.daily(days)}


@app.get("/api/energy/monthly")
def energy_monthly():
    return {"unit": "kWh per month", "points": data_service.monthly()}


@app.get("/api/predict/next-hour")
def predict_next_hour():
    return model_service.next_hour()


@app.get("/api/predict/forecast")
def predict_forecast(hours: int = Query(24, ge=1, le=48)):
    return model_service.forecast(hours)


@app.get("/api/model/metrics")
def model_metrics():
    return model_service.metrics()


@app.get("/api/model/test-predictions")
def model_test_predictions(hours: int = Query(168, ge=24, le=720)):
    return model_service.test_predictions(hours)


@app.get("/api/anomalies")
def anomalies(days: int = Query(30, ge=1, le=90), threshold: float = Query(3.5, gt=0, le=20)):
    return anomaly_service.detect_from_dataset(days, threshold)


@app.get("/api/bill/estimate")
def bill_estimate(
    rate: float = Query(config.DEFAULT_RATE_INR_PER_KWH, description="INR per kWh"),
    source: str = Query("actual", pattern="^(actual|forecast)$"),
    days: int = Query(30, ge=1, le=365),
):
    return bill_service.estimate(source, days, rate)


@app.get("/api/recommendations")
def recommendations(rate: float = Query(config.DEFAULT_RATE_INR_PER_KWH)):
    return recommendation_service.build(bill_service.validate_rate(rate))
