"""Download the UCI Individual Household Electric Power Consumption dataset.

Usage (from the backend folder, venv active):
    python download_dataset.py

Source: https://archive.ics.uci.edu/dataset/235 (CC BY 4.0, ~20 MB zip).
If the automatic download fails, download the zip manually from the UCI page,
extract household_power_consumption.txt and place it in backend/data/.
"""
import sys
import urllib.error
import urllib.request
import zipfile

from config import DATA_DIR, RAW_FILE, UCI_PAGE, UCI_ZIP_URL


def main() -> int:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if RAW_FILE.exists():
        print(f"Dataset already present: {RAW_FILE}")
        return 0

    zip_path = DATA_DIR / "dataset.zip"
    print(f"Downloading {UCI_ZIP_URL} ...")
    try:
        req = urllib.request.Request(UCI_ZIP_URL, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=120) as resp, open(zip_path, "wb") as out:
            while True:
                chunk = resp.read(1 << 20)
                if not chunk:
                    break
                out.write(chunk)
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        print(f"\nERROR: automatic download failed: {exc}")
        print("Manual steps:")
        print(f"  1. Open {UCI_PAGE}")
        print("  2. Click 'Download', extract the zip.")
        print(f"  3. Copy household_power_consumption.txt into {DATA_DIR}")
        return 1

    try:
        with zipfile.ZipFile(zip_path) as zf:
            members = [m for m in zf.namelist() if m.endswith("household_power_consumption.txt")]
            if not members:
                print("ERROR: household_power_consumption.txt not found inside the zip.")
                return 1
            with zf.open(members[0]) as src, open(RAW_FILE, "wb") as dst:
                dst.write(src.read())
    except zipfile.BadZipFile:
        print("ERROR: downloaded file is not a valid zip. Download manually (see above).")
        return 1
    finally:
        if zip_path.exists():
            zip_path.unlink()

    print(f"Saved {RAW_FILE} ({RAW_FILE.stat().st_size / 1e6:.1f} MB)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
