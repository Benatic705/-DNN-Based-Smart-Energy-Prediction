import pytest

import config
from services import data_service, model_service
from tests.helpers import make_series


@pytest.fixture(autouse=True)
def isolated_paths(tmp_path, monkeypatch):
    """Point all data/model paths at an empty temp folder for every test."""
    data_dir, models_dir = tmp_path / "data", tmp_path / "models"
    data_dir.mkdir()
    models_dir.mkdir()
    monkeypatch.setattr(config, "DATA_DIR", data_dir)
    monkeypatch.setattr(config, "MODELS_DIR", models_dir)
    monkeypatch.setattr(config, "RAW_FILE", data_dir / "household_power_consumption.txt")
    monkeypatch.setattr(config, "HOURLY_FILE", data_dir / "hourly_energy.csv")
    monkeypatch.setattr(config, "MODEL_FILE", models_dir / "energy_dnn.keras")
    monkeypatch.setattr(config, "SCALER_FILE", models_dir / "scaler.joblib")
    monkeypatch.setattr(config, "METRICS_FILE", models_dir / "metrics.json")
    monkeypatch.setattr(config, "TEST_PRED_FILE", models_dir / "test_predictions.csv")
    data_service._cache.update(mtime=None, path=None, series=None)
    model_service._state.update(mtime=None, model=None, scaler=None)
    yield


@pytest.fixture
def synthetic_dataset():
    s = make_series(days=60)
    df = s.to_frame("energy_kwh")
    df["interpolated"] = 0
    df.index.name = "timestamp"
    df.to_csv(config.HOURLY_FILE)
    return s
