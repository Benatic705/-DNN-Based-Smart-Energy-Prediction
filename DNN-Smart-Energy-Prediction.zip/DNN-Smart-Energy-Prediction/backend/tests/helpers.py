"""Synthetic data used ONLY by the automated tests (never by the application)."""
import numpy as np
import pandas as pd


def make_series(days: int = 60, seed: int = 0, start: str = "2010-01-01") -> pd.Series:
    rng = np.random.default_rng(seed)
    idx = pd.date_range(start, periods=days * 24, freq="h")
    base = 0.6 + 0.8 * np.exp(-((idx.hour - 20) ** 2) / 8.0) + 0.3 * (idx.dayofweek >= 5)
    values = base + rng.normal(0, 0.05, len(idx))
    return pd.Series(np.clip(values, 0.05, None), index=idx, name="energy_kwh")
