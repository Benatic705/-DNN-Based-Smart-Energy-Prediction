import pandas as pd
import pytest

import config
from preprocess_data import preprocess
from services import anomaly_service, bill_service
from services.errors import ServiceError
from tests.helpers import make_series


def test_bill_cost():
    assert bill_service.cost(10, 8.0) == 80.0


@pytest.mark.parametrize("rate", [0, -1, 1000])
def test_bill_rejects_bad_rate(rate):
    with pytest.raises(ServiceError):
        bill_service.validate_rate(rate)


def test_anomaly_flags_injected_spike():
    s = make_series(days=60)
    spike_ts = s.index[-30]
    s.loc[spike_ts] = 6.0
    res = anomaly_service.detect(s, days=14, threshold=3.5)
    assert any(a["timestamp"] == spike_ts.strftime("%Y-%m-%dT%H:%M:%S") for a in res["anomalies"])
    assert res["limitations"]


def test_anomaly_few_false_alarms_on_clean_data():
    res = anomaly_service.detect(make_series(days=60), days=14, threshold=4.0)
    assert res["anomaly_rate_pct"] < 2.0


def test_anomaly_needs_history():
    with pytest.raises(ServiceError):
        anomaly_service.detect(make_series(days=5), days=3)


def test_preprocess_handles_missing_and_invalid(tmp_path):
    rows = ["Date;Time;Global_active_power;Global_reactive_power"]
    for h in range(3):  # 3 hours of data
        for m in range(60):
            kw = "?" if (h == 1 and m < 40) else ("-1" if (h == 2 and m == 0) else "1.200")
            rows.append(f"16/12/2006;{17 + h}:{m:02d}:00;{kw};0.1")
    raw = tmp_path / "raw.txt"
    raw.write_text("\n".join(rows))
    out = preprocess(raw, tmp_path / "hourly.csv", verbose=False)
    assert len(out) == 3
    assert out["energy_kwh"].iloc[0] == pytest.approx(1.2)
    # hour 1 has only 20 valid minutes (<30) -> missing, then interpolated between neighbours
    assert out["interpolated"].iloc[1] == 1
    assert out["energy_kwh"].iloc[2] == pytest.approx(1.2)
    assert (tmp_path / "hourly.csv").exists()
