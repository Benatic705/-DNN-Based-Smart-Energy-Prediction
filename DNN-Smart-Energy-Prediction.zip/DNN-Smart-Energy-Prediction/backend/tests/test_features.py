import numpy as np
import pandas as pd
import pytest

from services.features import (
    FEATURE_COLUMNS,
    MIN_HISTORY,
    build_feature_frame,
    next_row_features,
    recursive_forecast,
)
from tests.helpers import make_series


def test_no_target_leakage():
    s = make_series(days=20)
    t = s.index[300]
    changed = s.copy()
    changed.loc[t] = 99.0  # altering the target hour must not change its own features
    a = build_feature_frame(s).loc[t]
    b = build_feature_frame(changed).loc[t]
    assert np.allclose(a.to_numpy(), b.to_numpy())


def test_future_values_do_not_affect_features():
    s = make_series(days=20)
    t = s.index[300]
    changed = s.copy()
    changed.iloc[301:] = 50.0
    assert np.allclose(build_feature_frame(s).loc[t], build_feature_frame(changed).loc[t])


def test_columns_and_warmup():
    f = build_feature_frame(make_series(days=20))
    assert list(f.columns) == FEATURE_COLUMNS
    assert f.iloc[: MIN_HISTORY - 1].isna().any(axis=1).all()
    assert not f.iloc[MIN_HISTORY:].isna().any(axis=None)


def test_next_row_matches_vectorised_features():
    s = make_series(days=20)
    hist = s.iloc[:-1]
    row = next_row_features(hist)
    expected = build_feature_frame(s).iloc[[-1]]
    assert row.index[0] == s.index[-1]
    assert np.allclose(row.to_numpy(), expected.to_numpy())


def test_next_row_requires_history():
    with pytest.raises(ValueError):
        next_row_features(make_series(days=3))


def test_recursive_forecast_shape_and_feedback():
    s = make_series(days=20)
    calls = []

    def fake_predict(rows):
        calls.append(rows["lag_1"].iloc[0])
        return np.array([1.0])

    out = recursive_forecast(fake_predict, s, 24)
    assert len(out) == 24
    assert out.index[0] == s.index[-1] + pd.Timedelta(hours=1)
    assert out.index[-1] == s.index[-1] + pd.Timedelta(hours=24)
    assert calls[1] == 1.0  # second step saw the first prediction as lag_1
