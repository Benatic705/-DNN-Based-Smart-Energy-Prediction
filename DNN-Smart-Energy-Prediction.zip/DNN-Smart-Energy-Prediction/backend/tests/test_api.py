import numpy as np
import pytest
from fastapi.testclient import TestClient

import config
from main import app
from services import model_service

client = TestClient(app)


def test_health_without_data_or_model():
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["dataset_available"] is False and body["model_available"] is False


def test_status_when_nothing_is_set_up():
    body = client.get("/api/status").json()
    assert body["dataset"]["available"] is False
    assert body["model"]["available"] is False
    assert "train_model.py" in body["model"]["hint"]


@pytest.mark.parametrize(
    "path",
    ["/api/energy/history", "/api/energy/daily", "/api/energy/monthly", "/api/anomalies",
     "/api/bill/estimate", "/api/recommendations", "/api/dataset/summary"],
)
def test_missing_dataset_returns_clear_503(path):
    r = client.get(path)
    assert r.status_code == 503
    assert "dataset" in r.json()["error"].lower()
    assert "preprocess_data.py" in r.json()["hint"]


@pytest.mark.parametrize("path", ["/api/predict/next-hour", "/api/predict/forecast", "/api/model/metrics", "/api/model/test-predictions"])
def test_missing_model_returns_clear_503(path, synthetic_dataset):
    r = client.get(path)
    assert r.status_code == 503
    assert "train_model.py" in r.json()["hint"]


def test_invalid_inputs(synthetic_dataset):
    assert client.get("/api/energy/history?days=0").status_code == 422
    assert client.get("/api/energy/history?days=abc").status_code == 422
    assert client.get("/api/bill/estimate?rate=-5").status_code == 422
    assert client.get("/api/bill/estimate?source=bogus").status_code == 422
    assert client.get("/api/anomalies?threshold=0").status_code == 422
    assert "error" in client.get("/api/energy/history?days=0").json()


def test_data_endpoints(synthetic_dataset):
    assert client.get("/api/dataset/status").json()["available"] is True
    h = client.get("/api/energy/history?days=3").json()
    assert len(h["points"]) == 72
    d = client.get("/api/energy/daily?days=10").json()["points"]
    assert len(d) == 10 and d[0]["complete"] is True
    assert len(client.get("/api/energy/monthly").json()["points"]) >= 2
    s = client.get("/api/dataset/summary?days=7").json()
    assert s["recent"]["total_kwh"] > 0


def test_bill_actual(synthetic_dataset):
    b = client.get("/api/bill/estimate?rate=10&days=7").json()
    assert b["estimated_cost_inr"] == pytest.approx(b["energy_kwh"] * 10, abs=0.01)
    assert "slabs" in b["disclaimer"]


def test_anomalies_and_recommendations(synthetic_dataset):
    a = client.get("/api/anomalies?days=14&threshold=3.5").json()
    assert a["limitations"] and "chart" in a
    r = client.get("/api/recommendations?rate=8").json()
    ids = [x["id"] for x in r["recommendations"]]
    assert "base-load" in ids and "peak-hours" in ids
    assert "forecast" not in ids  # no model trained


def test_forecast_plumbing_with_stub_predictor(synthetic_dataset, monkeypatch):
    """Tests the API plumbing only: the predictor is stubbed. Real-model output
    is verified by running train_model.py (see README)."""
    config.MODEL_FILE.write_bytes(b"x")
    config.SCALER_FILE.write_bytes(b"x")
    monkeypatch.setattr(model_service, "predict_rows", lambda rows: np.full(len(rows), 1.5))
    nh = client.get("/api/predict/next-hour").json()
    assert nh["predicted_kwh"] == 1.5
    fc = client.get("/api/predict/forecast?hours=24").json()
    assert len(fc["predictions"]) == 24 and fc["total_kwh"] == pytest.approx(36.0)
    b = client.get("/api/bill/estimate?source=forecast&rate=10").json()
    assert b["estimated_cost_inr"] == pytest.approx(360.0)
    rec = client.get("/api/recommendations").json()
    assert "forecast" in [x["id"] for x in rec["recommendations"]]


def test_cors_header_for_vite_origin():
    r = client.get("/api/health", headers={"Origin": "http://localhost:5173"})
    assert r.headers.get("access-control-allow-origin") == "http://localhost:5173"
