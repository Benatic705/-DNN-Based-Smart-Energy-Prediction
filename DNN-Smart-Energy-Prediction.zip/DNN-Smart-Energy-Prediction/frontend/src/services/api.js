const BASE = (import.meta.env.VITE_API_URL || "http://127.0.0.1:8000").replace(/\/$/, "");

export class ApiError extends Error {
  constructor(message, hint = "", status = 0) {
    super(message);
    this.hint = hint;
    this.status = status;
  }
}

async function request(path, params = {}) {
  const url = new URL(BASE + path);
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null) url.searchParams.set(k, v);
  });
  let res;
  try {
    res = await fetch(url.toString());
  } catch {
    throw new ApiError(
      "Cannot reach the backend API.",
      `Start it with: uvicorn main:app --port 8000 (expected at ${BASE})`
    );
  }
  let body = null;
  try {
    body = await res.json();
  } catch {
    /* non-JSON body */
  }
  if (!res.ok) {
    throw new ApiError(
      (body && (body.error || body.detail)) || `Request failed (${res.status})`,
      (body && body.hint) || "",
      res.status
    );
  }
  return body;
}

export const api = {
  status: () => request("/api/status"),
  summary: (days = 30) => request("/api/dataset/summary", { days }),
  history: (days = 7) => request("/api/energy/history", { days }),
  daily: (days = 30) => request("/api/energy/daily", { days }),
  monthly: () => request("/api/energy/monthly"),
  nextHour: () => request("/api/predict/next-hour"),
  forecast: (hours = 24) => request("/api/predict/forecast", { hours }),
  metrics: () => request("/api/model/metrics"),
  testPredictions: (hours = 168) => request("/api/model/test-predictions", { hours }),
  anomalies: (days = 30, threshold = 3.5) => request("/api/anomalies", { days, threshold }),
  bill: (rate, source = "actual", days = 30) => request("/api/bill/estimate", { rate, source, days }),
  recommendations: (rate) => request("/api/recommendations", { rate }),
};
