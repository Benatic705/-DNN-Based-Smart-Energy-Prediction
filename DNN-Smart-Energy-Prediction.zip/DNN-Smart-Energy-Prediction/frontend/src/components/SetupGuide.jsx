import { Card, Notice } from "./Ui";

const DATA_STEPS = `cd DNN-Smart-Energy-Prediction\\backend
.\\.venv\\Scripts\\python.exe download_dataset.py
.\\.venv\\Scripts\\python.exe preprocess_data.py`;

const MODEL_STEPS = `cd DNN-Smart-Energy-Prediction\\backend
.\\.venv\\Scripts\\python.exe train_model.py`;

/** Shown instead of a page when the dataset (kind="dataset") or the model (kind="model") is missing. */
export default function SetupGuide({ kind, status, onRefresh }) {
  const isDataset = kind === "dataset";
  return (
    <Card
      title={isDataset ? "Dataset not prepared yet" : "Model not trained yet"}
      subtitle="The dashboard shows real values only - nothing is displayed until this step is done."
      actions={
        <button className="btn ghost" onClick={onRefresh}>
          Check again
        </button>
      }
    >
      <Notice tone="warn">
        {isDataset
          ? status?.dataset?.message || "The hourly dataset file was not found by the backend."
          : status?.model?.hint || "No trained model file was found by the backend."}
      </Notice>
      <p>Run these commands in PowerShell, then press "Check again" (the backend does not need a restart):</p>
      <pre className="code">{isDataset ? DATA_STEPS : MODEL_STEPS}</pre>
      {isDataset && (
        <p className="muted small">
          If the automatic download fails, download the zip manually from{" "}
          <a href="https://archive.ics.uci.edu/dataset/235/individual+household+electric+power+consumption" target="_blank" rel="noreferrer">
            the UCI page
          </a>
          , extract <code>household_power_consumption.txt</code> into <code>backend\data</code>, then run the preprocess command.
        </p>
      )}
      {!isDataset && <p className="muted small">Training prints the held-out test MAE and RMSE when it finishes. It usually takes a few minutes on a CPU.</p>}
    </Card>
  );
}
