import { shortDate, shortTime } from "../utils/format";

// Colours chosen to stay readable on both the light and the dark theme.
export const COLORS = {
  actual: "#3b82f6",
  predicted: "#f97316",
  expected: "#94a3b8",
  limit: "#a78bfa",
  anomaly: "#ef4444",
  bar: "#3b82f6",
  barPartial: "#93b4f0",
};

export const GRID = "rgba(128,128,128,0.28)";
export const TICK = { fill: "#8a94a8", fontSize: 12 };
export const TOOLTIP = {
  contentStyle: {
    background: "var(--card)",
    border: "1px solid var(--border)",
    borderRadius: 8,
    color: "var(--text)",
  },
  labelStyle: { color: "var(--text)", fontWeight: 600 },
};

export const tickTime = (v) => shortTime(v);
export const tickDate = (v) => shortDate(v);
