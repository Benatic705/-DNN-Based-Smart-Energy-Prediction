export function Card({ title, subtitle, actions, children, className = "" }) {
  return (
    <section className={`card ${className}`}>
      {(title || actions) && (
        <div className="card-head">
          <div>
            {title && <h2>{title}</h2>}
            {subtitle && <p>{subtitle}</p>}
          </div>
          {actions && <div className="actions">{actions}</div>}
        </div>
      )}
      {children}
    </section>
  );
}

export function Stat({ label, value, sub }) {
  return (
    <section className="card">
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      {sub && <div className="stat-sub">{sub}</div>}
    </section>
  );
}

export function Loading({ label = "Loading..." }) {
  return (
    <div className="loading" role="status">
      <span className="spinner" />
      {label}
    </div>
  );
}

export function Notice({ tone = "", children }) {
  return <div className={`notice ${tone}`}>{children}</div>;
}

export function ErrorBox({ error, onRetry }) {
  return (
    <div className="notice bad" role="alert">
      <strong>{error?.message || "Something went wrong."}</strong>
      {error?.hint && (
        <div className="hint">
          <code>{error.hint}</code>
        </div>
      )}
      {onRetry && (
        <div className="hint">
          <button className="btn ghost" onClick={onRetry}>
            Try again
          </button>
        </div>
      )}
    </div>
  );
}

export function Pill({ tone = "", children }) {
  return (
    <span className={`pill ${tone}`}>
      <span className="dot" />
      {children}
    </span>
  );
}

/** Renders loading / error / data states of a useApi() result. children(data) renders the data. */
export function Async({ state, children, label }) {
  if (state.error) return <ErrorBox error={state.error} onRetry={state.reload} />;
  if (!state.data) return <Loading label={label} />;
  return <div className={state.loading ? "dim" : ""}>{children(state.data)}</div>;
}

export function Tabs({ value, options, onChange }) {
  return (
    <div className="tabs" role="tablist">
      {options.map((o) => (
        <button
          key={o.value}
          role="tab"
          aria-selected={value === o.value}
          className={value === o.value ? "active" : ""}
          onClick={() => onChange(o.value)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Select({ label, value, options, onChange }) {
  return (
    <label className="field">
      {label}
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}
