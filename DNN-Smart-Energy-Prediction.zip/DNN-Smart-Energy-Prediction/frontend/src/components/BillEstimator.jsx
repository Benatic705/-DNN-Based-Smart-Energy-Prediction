import { useState } from "react";
import { api } from "../services/api";
import { inr, kwh, longTime } from "../utils/format";
import { Card, ErrorBox, Loading, Notice, Select } from "./Ui";

/** Calls GET /api/bill/estimate for actual or forecast energy at the chosen rate. */
export default function BillEstimator({ rate, modelAvailable }) {
  const [source, setSource] = useState("actual");
  const [days, setDays] = useState("30");
  const [state, setState] = useState({ loading: false, data: null, error: null });

  const calculate = () => {
    setState({ loading: true, data: null, error: null });
    api
      .bill(rate, source, Number(days))
      .then((data) => setState({ loading: false, data, error: null }))
      .catch((error) => setState({ loading: false, data: null, error }));
  };

  const sources = [
    { value: "actual", label: "Actual (last N days of data)" },
    { value: "forecast", label: modelAvailable ? "DNN forecast (next 24 h)" : "DNN forecast (train model first)" },
  ];
  const { loading, data, error } = state;

  return (
    <Card
      title="Electricity bill estimator"
      subtitle={`Energy x flat rate of ${rate} INR/kWh (change the rate in the top bar).`}
      actions={
        <>
          <Select label="Based on" value={source} options={sources} onChange={setSource} />
          {source === "actual" && (
            <Select
              label="Days"
              value={days}
              onChange={setDays}
              options={[7, 30, 90, 180, 365].map((d) => ({ value: String(d), label: `${d}` }))}
            />
          )}
          <button className="btn" onClick={calculate} disabled={loading || (source === "forecast" && !modelAvailable)}>
            Calculate
          </button>
        </>
      }
    >
      {loading && <Loading label="Calculating..." />}
      {error && <ErrorBox error={error} />}
      {!loading && !error && !data && <p className="muted">Choose a source and press Calculate.</p>}
      {data && (
        <>
          <div className="grid stats" style={{ marginBottom: 8 }}>
            <div>
              <div className="stat-label">Energy</div>
              <div className="stat-value">{kwh(data.energy_kwh)}</div>
              <div className="stat-sub">
                {longTime(data.period.start)} to {longTime(data.period.end)}
              </div>
            </div>
            <div>
              <div className="stat-label">Estimated cost</div>
              <div className="stat-value">{inr(data.estimated_cost_inr)}</div>
              <div className="stat-sub">at {data.rate_inr_per_kwh} INR/kWh</div>
            </div>
            <div>
              <div className="stat-label">Projected 30-day cost</div>
              <div className="stat-value">{inr(data.projected_30_day_cost_inr)}</div>
              <div className="stat-sub">
                {data.source === "forecast" ? "if every day matched this forecast" : "at the average daily use of this period"}
              </div>
            </div>
          </div>
          <Notice>{data.disclaimer}</Notice>
        </>
      )}
    </Card>
  );
}
