import { Async, Card, Notice, Pill } from "../components/Ui";
import { useApi } from "../hooks/useApi";
import { api } from "../services/api";

const TONE = { high: "bad", medium: "warn", low: "ok" };

function Evidence({ data }) {
  const entries = Object.entries(data || {});
  if (!entries.length) return null;
  return (
    <div className="kv">
      {entries.map(([k, v]) => (
        <span key={k}>
          {k.replace(/_/g, " ")}: <b>{Array.isArray(v) ? v.join(", ") : String(v)}</b>
        </span>
      ))}
    </div>
  );
}

export default function Recommendations({ rate }) {
  const recs = useApi(() => api.recommendations(rate), [rate]);

  return (
    <Async state={recs}>
      {(d) => (
        <>
          <Notice>
            {d.method} Based on the {d.based_on}. Cost figures use {d.rate_inr_per_kwh} INR/kWh (change it in the top bar).
          </Notice>
          {d.recommendations.map((r) => (
            <Card key={r.id} className={`rec ${r.priority}`}>
              <div className="card-head" style={{ marginBottom: 0 }}>
                <div>
                  <div className="stat-label">{r.category}</div>
                  <h2>{r.title}</h2>
                </div>
                <Pill tone={TONE[r.priority]}>{r.priority} priority</Pill>
              </div>
              <p>{r.detail}</p>
              <Evidence data={r.evidence} />
            </Card>
          ))}
        </>
      )}
    </Async>
  );
}
