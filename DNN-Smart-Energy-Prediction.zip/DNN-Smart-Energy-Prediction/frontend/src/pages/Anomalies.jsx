import { useState } from "react";
import { CartesianGrid, ComposedChart, Legend, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Async, Card, Notice, Pill, Select, Stat } from "../components/Ui";
import { COLORS, GRID, TICK, TOOLTIP, tickTime } from "../components/chartTheme";
import { useApi } from "../hooks/useApi";
import { api } from "../services/api";
import { kwh, longTime, shortTime } from "../utils/format";

const DAYS = [7, 14, 30, 60, 90];

export default function Anomalies() {
  const [days, setDays] = useState("30");
  const [thresholdText, setThresholdText] = useState("3.5");
  const [applied, setApplied] = useState({ days: 30, threshold: 3.5 });

  const t = Number(thresholdText);
  const thresholdValid = thresholdText.trim() !== "" && Number.isFinite(t) && t > 0 && t <= 20;

  const result = useApi(() => api.anomalies(applied.days, applied.threshold), [applied.days, applied.threshold]);

  const apply = () => {
    if (thresholdValid) setApplied({ days: Number(days), threshold: t });
  };

  return (
    <>
      <Card
        title="Detection settings"
        subtitle="Flags hours that are unusually high compared with the same hour of day on similar days (weekday / weekend)."
        actions={
          <>
            <Select label="Window" value={days} onChange={setDays} options={DAYS.map((d) => ({ value: String(d), label: `last ${d} days` }))} />
            <label className="field">
              Threshold (robust z)
              <input
                type="number"
                step="0.5"
                min="0.5"
                max="20"
                value={thresholdText}
                className={thresholdValid ? "" : "invalid"}
                onChange={(e) => setThresholdText(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && apply()}
              />
            </label>
            <button className="btn" onClick={apply} disabled={!thresholdValid}>
              Run detection
            </button>
          </>
        }
      >
        {!thresholdValid && <p className="muted small">Enter a threshold greater than 0 and at most 20 (default 3.5).</p>}
        <p className="muted small" style={{ margin: 0 }}>
          A higher threshold gives fewer, more extreme flags; a lower one finds more events but more false alarms.
        </p>
      </Card>

      <Async state={result}>
        {(d) => (
          <>
            <div className="grid stats">
              <Stat label="Flagged hours" value={d.anomaly_count} sub={`of ${d.valid_hours.toLocaleString("en-IN")} valid hours (${d.anomaly_rate_pct}%)`} />
              <Stat label="Window" value={`${d.days} days`} sub={`${longTime(d.window_start)} to ${longTime(d.window_end)}`} />
              <Stat label="Threshold" value={d.threshold} sub="robust z-score (median / MAD)" />
            </div>

            <Card title="Consumption vs expected" subtitle="Red dots are hours flagged as unusually high. 'Expected' is the median for that hour-of-day and weekday/weekend group.">
              <div className="chart tall">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={d.chart} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                    <CartesianGrid stroke={GRID} strokeDasharray="3 3" />
                    <XAxis dataKey="timestamp" tickFormatter={tickTime} tick={TICK} minTickGap={60} />
                    <YAxis tick={TICK} width={48} />
                    <Tooltip {...TOOLTIP} labelFormatter={shortTime} formatter={(v, n) => [kwh(v, 3), n]} />
                    <Legend />
                    <Line name="Actual" type="monotone" dataKey="energy_kwh" stroke={COLORS.actual} strokeWidth={1.5} dot={false} isAnimationActive={false} />
                    <Line name="Expected (median)" type="monotone" dataKey="expected_kwh" stroke={COLORS.expected} strokeWidth={1.5} strokeDasharray="4 3" dot={false} isAnimationActive={false} />
                    <Line name="Upper limit" type="monotone" dataKey="upper_limit_kwh" stroke={COLORS.limit} strokeWidth={1} dot={false} isAnimationActive={false} />
                    <Line name="Flagged" dataKey="anomaly_kwh" stroke="none" dot={{ r: 4, fill: COLORS.anomaly, stroke: COLORS.anomaly }} activeDot={{ r: 6 }} isAnimationActive={false} legendType="circle" />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card title="Flagged hours" subtitle={`Most recent first${d.anomaly_count > d.anomalies.length ? `, showing ${d.anomalies.length} of ${d.anomaly_count}` : ""}`}>
              {d.anomalies.length === 0 ? (
                <p className="muted">No hours exceeded the threshold in this window.</p>
              ) : (
                <div className="table-wrap" style={{ maxHeight: 360, overflowY: "auto" }}>
                  <table>
                    <thead>
                      <tr>
                        <th>Hour</th>
                        <th className="num">Actual</th>
                        <th className="num">Expected</th>
                        <th className="num">Robust z</th>
                        <th>Severity</th>
                      </tr>
                    </thead>
                    <tbody>
                      {d.anomalies.map((a) => (
                        <tr key={a.timestamp}>
                          <td>{longTime(a.timestamp)}</td>
                          <td className="num">{kwh(a.energy_kwh, 3)}</td>
                          <td className="num">{kwh(a.expected_kwh, 3)}</td>
                          <td className="num">{a.robust_z}</td>
                          <td>
                            <Pill tone={a.severity === "high" ? "bad" : "warn"}>{a.severity}</Pill>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>

            <Card title="How it works and its limits">
              <p style={{ marginTop: 0 }}>{d.method}. The baseline is fitted on data before the inspected window when enough history exists.</p>
              <Notice tone="warn">A flag is a statistical signal, not a confirmed fault.</Notice>
              <ul className="plain">
                {d.limitations.map((l) => (
                  <li key={l}>{l}</li>
                ))}
              </ul>
            </Card>
          </>
        )}
      </Async>
    </>
  );
}
