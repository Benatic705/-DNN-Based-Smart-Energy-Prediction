import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Async, Card, Notice, Stat } from "../components/Ui";
import { COLORS, GRID, TICK, TOOLTIP, tickDate, tickTime } from "../components/chartTheme";
import { useApi } from "../hooks/useApi";
import { api } from "../services/api";
import { inr, kwh, longTime, num, shortDate, shortTime } from "../utils/format";

export default function Overview({ status, rate, goto }) {
  const ds = status.dataset;
  const modelOk = status.model.available;

  const summary = useApi(() => api.summary(30), []);
  const bill = useApi(() => api.bill(rate, "actual", 30), [rate]);
  const daily = useApi(() => api.daily(30), []);
  const next = useApi(() => (modelOk ? api.nextHour() : Promise.resolve(null)), [modelOk]);
  const forecast = useApi(() => (modelOk ? api.forecast(24) : Promise.resolve(null)), [modelOk]);
  const metrics = useApi(() => (modelOk ? api.metrics() : Promise.resolve(null)), [modelOk]);

  return (
    <>
      <Notice>
        All values come from the real historical dataset ({longTime(ds.start)} to {longTime(ds.end)}). "Recent" means the last
        days of that dataset, not today. Forecasts start after its last record.
      </Notice>

      <div className="grid stats">
        <Stat
          label="Total historical energy"
          value={kwh(ds.total_kwh, 0)}
          sub={`${ds.valid_hours.toLocaleString("en-IN")} valid hours, ${ds.missing_hours.toLocaleString("en-IN")} missing`}
        />
        <Async state={summary}>
          {(d) => (
            <Stat
              label="Last 30 days"
              value={kwh(d.recent.total_kwh, 0)}
              sub={`${kwh(d.recent.avg_daily_kwh, 1)}/day, peak hour ${kwh(d.recent.peak_hour_kwh, 2)}`}
            />
          )}
        </Async>
        <Async state={bill}>
          {(d) => <Stat label="Est. bill, last 30 days" value={inr(d.estimated_cost_inr)} sub={`flat ${d.rate_inr_per_kwh} INR/kWh, excludes taxes and fixed charges`} />}
        </Async>
        {modelOk ? (
          <Async state={next}>
            {(d) => d && <Stat label="Next-hour prediction" value={kwh(d.predicted_kwh, 3)} sub={`for ${longTime(d.timestamp)}`} />}
          </Async>
        ) : (
          <Stat label="Next-hour prediction" value="Not available" sub="Train the model to enable" />
        )}
      </div>

      {!modelOk && (
        <Notice tone="warn">
          The DNN has not been trained yet, so there are no predictions or accuracy metrics.{" "}
          <button className="btn ghost" onClick={() => goto("predictions")}>
            See how to train it
          </button>
        </Notice>
      )}

      <div className="grid two">
        <Card title="Next 24 hours (DNN forecast)" subtitle="Recursive forecast from the last record in the dataset">
          {modelOk ? (
            <Async state={forecast}>
              {(d) =>
                d && (
                  <>
                    <div className="chart">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={d.predictions} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                          <CartesianGrid stroke={GRID} strokeDasharray="3 3" />
                          <XAxis dataKey="timestamp" tickFormatter={tickTime} tick={TICK} minTickGap={40} />
                          <YAxis tick={TICK} width={48} />
                          <Tooltip {...TOOLTIP} labelFormatter={shortTime} formatter={(v) => [kwh(v, 3), "Predicted"]} />
                          <Line type="monotone" dataKey="predicted_kwh" stroke={COLORS.predicted} strokeWidth={2.5} dot={false} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                    <p className="muted small">Total predicted: {kwh(d.total_kwh, 2)} (kWh per hour on the y-axis).</p>
                  </>
                )
              }
            </Async>
          ) : (
            <p className="muted">Available after the model is trained.</p>
          )}
        </Card>

        <Card title="Daily consumption, last 30 days" subtitle="Lighter bars are days with missing hours">
          <Async state={daily}>
            {(d) => (
              <div className="chart">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={d.points} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                    <CartesianGrid stroke={GRID} strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickFormatter={tickDate} tick={TICK} minTickGap={24} />
                    <YAxis tick={TICK} width={48} />
                    <Tooltip {...TOOLTIP} labelFormatter={shortDate} formatter={(v) => [kwh(v, 2), "Energy"]} />
                    <Bar dataKey="energy_kwh" fill={COLORS.bar} radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </Async>
        </Card>
      </div>

      <Card title="Model accuracy (held-out test set)" subtitle="Measured on the final 15% of the timeline, never used in training">
        {modelOk ? (
          <Async state={metrics}>
            {(m) =>
              m && (
                <div className="grid stats" style={{ marginBottom: 0 }}>
                  <div>
                    <div className="stat-label">MAE</div>
                    <div className="stat-value">{num(m.test.mae, 3)} kWh</div>
                  </div>
                  <div>
                    <div className="stat-label">RMSE</div>
                    <div className="stat-value">{num(m.test.rmse, 3)} kWh</div>
                  </div>
                  <div>
                    <div className="stat-label">Trained</div>
                    <div className="stat-value" style={{ fontSize: "1.1rem" }}>{longTime(m.trained_at)}</div>
                    <div className="stat-sub">TensorFlow {m.tensorflow_version}</div>
                  </div>
                </div>
              )
            }
          </Async>
        ) : (
          <p className="muted">No metrics yet - the model has not been trained.</p>
        )}
      </Card>
    </>
  );
}
