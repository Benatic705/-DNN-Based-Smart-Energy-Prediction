import { useState } from "react";
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import BillEstimator from "../components/BillEstimator";
import { Async, Card, Select, Tabs } from "../components/Ui";
import { COLORS, GRID, TICK, TOOLTIP, tickDate, tickTime } from "../components/chartTheme";
import { useApi } from "../hooks/useApi";
import { api } from "../services/api";
import { inr, kwh, longTime, shortDate, shortTime } from "../utils/format";

const HOURLY_DAYS = [1, 3, 7, 14, 30, 60];
const DAILY_DAYS = [7, 30, 90, 180, 365];
const STAT_DAYS = [7, 30, 90, 365];

export default function Analytics({ status, rate }) {
  const [view, setView] = useState("daily");
  const [days, setDays] = useState("30");
  const [statDays, setStatDays] = useState("30");

  const changeView = (v) => {
    setView(v);
    setDays(v === "hourly" ? "7" : "30");
  };

  const series = useApi(() => {
    const d = Number(days);
    if (view === "hourly") return api.history(d);
    if (view === "daily") return api.daily(d);
    return api.monthly();
  }, [view, days]);
  const recent = useApi(() => api.summary(Number(statDays)), [statDays]);
  const monthly = useApi(() => api.monthly(), []);

  const dayOptions = (view === "hourly" ? HOURLY_DAYS : DAILY_DAYS).map((d) => ({ value: String(d), label: `${d} days` }));

  return (
    <>
      <Card
        title="Consumption over time"
        subtitle="Real hourly, daily and monthly energy from the dataset"
        actions={
          <>
            <Tabs
              value={view}
              onChange={changeView}
              options={[
                { value: "hourly", label: "Hourly" },
                { value: "daily", label: "Daily" },
                { value: "monthly", label: "Monthly" },
              ]}
            />
            {view !== "monthly" && <Select label="Range" value={days} options={dayOptions} onChange={setDays} />}
          </>
        }
      >
        <Async state={series}>
          {(d) => (
            <div className="chart tall">
              <ResponsiveContainer width="100%" height="100%">
                {view === "hourly" ? (
                  <LineChart data={d.points} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                    <CartesianGrid stroke={GRID} strokeDasharray="3 3" />
                    <XAxis dataKey="timestamp" tickFormatter={tickTime} tick={TICK} minTickGap={50} />
                    <YAxis tick={TICK} width={48} />
                    <Tooltip {...TOOLTIP} labelFormatter={shortTime} formatter={(v) => [kwh(v, 3), "Energy"]} />
                    <Line type="monotone" dataKey="energy_kwh" stroke={COLORS.actual} strokeWidth={1.8} dot={false} connectNulls={false} />
                  </LineChart>
                ) : (
                  <BarChart data={d.points} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                    <CartesianGrid stroke={GRID} strokeDasharray="3 3" />
                    <XAxis
                      dataKey={view === "daily" ? "date" : "month"}
                      tickFormatter={view === "daily" ? tickDate : undefined}
                      tick={TICK}
                      minTickGap={24}
                    />
                    <YAxis tick={TICK} width={52} />
                    <Tooltip
                      {...TOOLTIP}
                      labelFormatter={view === "daily" ? shortDate : undefined}
                      formatter={(v) => [kwh(v, 1), "Energy"]}
                    />
                    <Bar dataKey="energy_kwh" radius={[3, 3, 0, 0]}>
                      {d.points.map((p, i) => (
                        <Cell
                          key={i}
                          fill={(view === "daily" ? p.complete : p.coverage_pct >= 95) ? COLORS.bar : COLORS.barPartial}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          )}
        </Async>
        <p className="muted small">
          {view === "hourly" ? "kWh per hour." : view === "daily" ? "kWh per day; lighter bars have fewer than 22 valid hours." : "kWh per month; lighter bars have under 95% data coverage."}
        </p>
      </Card>

      <Card
        title="Recent consumption statistics"
        subtitle="Window ends at the last valid record of the dataset"
        actions={
          <Select
            label="Window"
            value={statDays}
            onChange={setStatDays}
            options={STAT_DAYS.map((d) => ({ value: String(d), label: `last ${d} days` }))}
          />
        }
      >
        <Async state={recent}>
          {({ recent: r }) => (
            <div className="grid stats" style={{ marginBottom: 0 }}>
              <div>
                <div className="stat-label">Total</div>
                <div className="stat-value">{kwh(r.total_kwh, 1)}</div>
                <div className="stat-sub">{inr(r.total_kwh * rate)} at {rate} INR/kWh</div>
              </div>
              <div>
                <div className="stat-label">Average per day</div>
                <div className="stat-value">{kwh(r.avg_daily_kwh, 1)}</div>
              </div>
              <div>
                <div className="stat-label">Average per hour</div>
                <div className="stat-value">{kwh(r.avg_hourly_kwh, 3)}</div>
              </div>
              <div>
                <div className="stat-label">Peak hour</div>
                <div className="stat-value">{kwh(r.peak_hour_kwh, 2)}</div>
                <div className="stat-sub">{longTime(r.peak_hour_at)}</div>
              </div>
            </div>
          )}
        </Async>
      </Card>

      <Card title="Monthly summary" subtitle={`Cost = energy x ${rate} INR/kWh (flat rate; no slabs, fixed charges or taxes). Calculated from real records.`}>
        <Async state={monthly}>
          {(d) => (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Month</th>
                    <th className="num">Energy (kWh)</th>
                    <th className="num">Data coverage</th>
                    <th className="num">Cost on recorded hours</th>
                  </tr>
                </thead>
                <tbody>
                  {d.points.map((m) => (
                    <tr key={m.month}>
                      <td>{m.month}</td>
                      <td className="num">{m.energy_kwh.toLocaleString("en-IN")}</td>
                      <td className="num">{m.coverage_pct}%</td>
                      <td className="num">{inr(m.energy_kwh * rate)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Async>
      </Card>

      <BillEstimator rate={rate} modelAvailable={status.model.available} />
    </>
  );
}
