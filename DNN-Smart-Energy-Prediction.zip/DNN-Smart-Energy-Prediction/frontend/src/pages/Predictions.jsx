import { useState } from "react";
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import SetupGuide from "../components/SetupGuide";
import { Async, Card, Notice, Select, Stat } from "../components/Ui";
import { COLORS, GRID, TICK, TOOLTIP, tickTime } from "../components/chartTheme";
import { useApi } from "../hooks/useApi";
import { api } from "../services/api";
import { kwh, longTime, num, shortTime } from "../utils/format";

const FORECAST_HOURS = [6, 12, 24, 48];
const TEST_HOURS = [24, 72, 168, 336, 720];

function MetricRow({ name, m }) {
  return (
    <tr>
      <td>{name}</td>
      <td className="num">{m && m.mae != null ? num(m.mae, 4) : "-"}</td>
      <td className="num">{m && m.rmse != null ? num(m.rmse, 4) : "-"}</td>
    </tr>
  );
}

export default function Predictions({ status, onRefresh }) {
  const modelOk = status.model.available;
  const [fh, setFh] = useState("24");
  const [th, setTh] = useState("168");

  const next = useApi(() => (modelOk ? api.nextHour() : Promise.resolve(null)), [modelOk]);
  const forecast = useApi(() => (modelOk ? api.forecast(Number(fh)) : Promise.resolve(null)), [modelOk, fh]);
  const test = useApi(() => (modelOk ? api.testPredictions(Number(th)) : Promise.resolve(null)), [modelOk, th]);
  const metrics = useApi(() => (modelOk ? api.metrics() : Promise.resolve(null)), [modelOk]);

  if (!modelOk) return <SetupGuide kind="model" status={status} onRefresh={onRefresh} />;

  return (
    <>
      <Async state={next}>
        {(d) =>
          d && (
            <div className="grid stats">
              <Stat label="Next-hour prediction" value={kwh(d.predicted_kwh, 3)} sub={`for ${longTime(d.timestamp)}`} />
              <Stat label="Based on data until" value={longTime(d.based_on_data_until)} sub="last record in the dataset" />
            </div>
          )
        }
      </Async>

      <Card
        title="Forecast"
        subtitle="Recursive multi-step forecast: each predicted hour is fed back in as an input, so error grows with the horizon."
        actions={<Select label="Horizon" value={fh} onChange={setFh} options={FORECAST_HOURS.map((h) => ({ value: String(h), label: `${h} hours` }))} />}
      >
        <Async state={forecast}>
          {(d) =>
            d && (
              <>
                <div className="chart tall">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={d.predictions} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                      <CartesianGrid stroke={GRID} strokeDasharray="3 3" />
                      <XAxis dataKey="timestamp" tickFormatter={tickTime} tick={TICK} minTickGap={40} />
                      <YAxis tick={TICK} width={48} />
                      <Tooltip {...TOOLTIP} labelFormatter={shortTime} formatter={(v) => [kwh(v, 3), "Predicted"]} />
                      <Line type="monotone" dataKey="predicted_kwh" stroke={COLORS.predicted} strokeWidth={2.5} dot={{ r: 2 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <p className="muted small">
                  Total over {d.hours} hours: <b>{kwh(d.total_kwh, 2)}</b>. Forecast origin: {longTime(d.based_on_data_until)}.
                </p>
              </>
            )
          }
        </Async>
      </Card>

      <Card
        title="Actual vs predicted (held-out test set)"
        subtitle="One-step-ahead predictions on hours the model never saw in training or validation."
        actions={<Select label="Show last" value={th} onChange={setTh} options={TEST_HOURS.map((h) => ({ value: String(h), label: `${h} hours` }))} />}
      >
        <Async state={test}>
          {(d) =>
            d && (
              <div className="chart tall">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={d.points} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                    <CartesianGrid stroke={GRID} strokeDasharray="3 3" />
                    <XAxis dataKey="timestamp" tickFormatter={tickTime} tick={TICK} minTickGap={50} />
                    <YAxis tick={TICK} width={48} />
                    <Tooltip {...TOOLTIP} labelFormatter={shortTime} formatter={(v, n) => [kwh(v, 3), n]} />
                    <Legend />
                    <Line type="monotone" name="Actual" dataKey="actual_kwh" stroke={COLORS.actual} strokeWidth={2} dot={false} />
                    <Line type="monotone" name="Predicted" dataKey="predicted_kwh" stroke={COLORS.predicted} strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )
          }
        </Async>
      </Card>

      <Card title="Model evaluation" subtitle="Computed by train_model.py on a chronological split; no shuffling.">
        <Async state={metrics}>
          {(m) =>
            m && (
              <>
                <div className="table-wrap">
                  <table>
                    <thead>
                      <tr>
                        <th>Evaluation</th>
                        <th className="num">MAE (kWh)</th>
                        <th className="num">RMSE (kWh)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <MetricRow name="DNN - test set, 1 hour ahead" m={m.test} />
                      <MetricRow name="DNN - validation set, 1 hour ahead" m={m.validation} />
                      <MetricRow name={`DNN - test set, 24 h recursive (${m.test_24h_recursive.origins_evaluated} origins)`} m={m.test_24h_recursive} />
                      <MetricRow name="Baseline: same as previous hour" m={m.baselines_on_test.persistence_last_hour} />
                      <MetricRow name="Baseline: same hour yesterday" m={m.baselines_on_test.seasonal_naive_24h} />
                      <MetricRow name="Baseline: training mean" m={m.baselines_on_test.train_mean} />
                    </tbody>
                  </table>
                </div>
                <p className="muted small">
                  Baselines show what trivial rules score on the same test hours. A useful model should beat them; compare the rows
                  yourself rather than trusting a single number.
                </p>
                <div className="grid two" style={{ marginTop: 14, marginBottom: 0 }}>
                  <div>
                    <div className="stat-label">Data split</div>
                    <ul className="plain">
                      {["train", "validation", "test"].map((k) => (
                        <li key={k}>
                          {k}: {m.split[k].rows.toLocaleString("en-IN")} rows, {longTime(m.split[k].start.replace(" ", "T"))} to {longTime(m.split[k].end.replace(" ", "T"))}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div className="stat-label">Model and training</div>
                    <ul className="plain">
                      <li>{m.architecture}</li>
                      <li>
                        {m.training.epochs_run} epochs run (max {m.training.epochs_max}), batch {m.training.batch_size}, {m.training.seconds}s
                      </li>
                      <li>{m.features.length} input features; trained {longTime(m.trained_at)}</li>
                    </ul>
                  </div>
                </div>
              </>
            )
          }
        </Async>
      </Card>

      <Notice>Predictions are statistical estimates from one household's history. They are not guarantees and are not live meter data.</Notice>
    </>
  );
}
