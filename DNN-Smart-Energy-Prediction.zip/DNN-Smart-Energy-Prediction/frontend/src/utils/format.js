export const kwh = (v, d = 2) => (v == null ? "—" : `${Number(v).toLocaleString("en-IN", { maximumFractionDigits: d })} kWh`);
export const inr = (v) => (v == null ? "—" : `₹${Number(v).toLocaleString("en-IN", { maximumFractionDigits: 0 })}`);
export const num = (v, d = 3) => (v == null ? "—" : Number(v).toFixed(d));

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** "2010-11-26T14:00:00" -> "26 Nov 14:00" (parsed as plain text: no timezone shifts). */
export function shortTime(ts) {
  if (!ts) return "";
  const [d, t] = ts.split("T");
  const [, m, day] = d.split("-");
  return `${Number(day)} ${MONTHS[Number(m) - 1]} ${t.slice(0, 5)}`;
}

export function shortDate(d) {
  if (!d) return "";
  const [, m, day] = d.split("-");
  return `${Number(day)} ${MONTHS[Number(m) - 1]}`;
}

export function longTime(ts) {
  if (!ts) return "—";
  const [d, t] = ts.split("T");
  const [y, m, day] = d.split("-");
  return `${Number(day)} ${MONTHS[Number(m) - 1]} ${y}, ${t.slice(0, 5)}`;
}
