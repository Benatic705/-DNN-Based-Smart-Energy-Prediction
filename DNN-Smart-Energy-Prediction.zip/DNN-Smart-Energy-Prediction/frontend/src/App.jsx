import { useEffect, useState } from "react";
import SetupGuide from "./components/SetupGuide";
import { Async, Pill } from "./components/Ui";
import { useApi } from "./hooks/useApi";
import Analytics from "./pages/Analytics";
import Anomalies from "./pages/Anomalies";
import Overview from "./pages/Overview";
import Predictions from "./pages/Predictions";
import Recommendations from "./pages/Recommendations";
import { api } from "./services/api";

const PAGES = [
  { id: "overview", label: "Overview", title: "Overview", icon: "▣" },
  { id: "analytics", label: "Energy analytics", title: "Energy analytics", icon: "▤" },
  { id: "predictions", label: "AI predictions", title: "AI predictions", icon: "◈" },
  { id: "anomalies", label: "Anomaly detection", title: "Anomaly detection", icon: "△" },
  { id: "recommendations", label: "Recommendations", title: "Energy-saving recommendations", icon: "✦" },
];

const DEFAULT_RATE = 8;

function pageFromHash() {
  const id = window.location.hash.replace("#", "");
  return PAGES.some((p) => p.id === id) ? id : "overview";
}

function loadRate() {
  try {
    const v = Number(window.localStorage.getItem("energy-rate"));
    if (v > 0 && v <= 100) return v;
  } catch {
    /* storage unavailable */
  }
  return DEFAULT_RATE;
}

export default function App() {
  const [page, setPage] = useState(pageFromHash);
  const [menuOpen, setMenuOpen] = useState(false);
  const [rate, setRate] = useState(loadRate);
  const [rateText, setRateText] = useState(String(loadRate()));
  const status = useApi(() => api.status(), []);

  useEffect(() => {
    const onHash = () => setPage(pageFromHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const goto = (id) => {
    window.location.hash = id;
    setPage(id);
    setMenuOpen(false);
  };

  const rateNum = Number(rateText);
  const rateValid = rateText.trim() !== "" && Number.isFinite(rateNum) && rateNum > 0 && rateNum <= 100;
  const onRate = (text) => {
    setRateText(text);
    const n = Number(text);
    if (text.trim() !== "" && Number.isFinite(n) && n > 0 && n <= 100) {
      setRate(n);
      try {
        window.localStorage.setItem("energy-rate", String(n));
      } catch {
        /* ignore */
      }
    }
  };

  const current = PAGES.find((p) => p.id === page);
  const st = status.data;

  const renderPage = (s) => {
    if (!s.dataset.available) return <SetupGuide kind="dataset" status={s} onRefresh={status.reload} />;
    const props = { status: s, rate, goto, onRefresh: status.reload };
    switch (page) {
      case "analytics":
        return <Analytics {...props} />;
      case "predictions":
        return <Predictions {...props} />;
      case "anomalies":
        return <Anomalies {...props} />;
      case "recommendations":
        return <Recommendations {...props} />;
      default:
        return <Overview {...props} />;
    }
  };

  return (
    <div className="app">
      <aside className={`sidebar ${menuOpen ? "open" : ""}`} aria-label="Main navigation">
        <div className="brand">
          <div className="brand-mark">⚡</div>
          <div>
            Smart Energy DNN
            <small>Prediction &amp; optimization</small>
          </div>
        </div>
        {PAGES.map((p) => (
          <button key={p.id} className={`nav-btn ${page === p.id ? "active" : ""}`} onClick={() => goto(p.id)}>
            <span aria-hidden="true">{p.icon}</span>
            {p.label}
          </button>
        ))}
        <div className="sidebar-foot">Historical dataset analysis. Not live metering.</div>
      </aside>
      <div className={`backdrop ${menuOpen ? "open" : ""}`} onClick={() => setMenuOpen(false)} />

      <main className="main">
        <header className="topbar">
          <button className="btn ghost menu-btn" onClick={() => setMenuOpen((o) => !o)} aria-label="Toggle navigation menu">
            Menu
          </button>
          <h1>{current.title}</h1>
          <label className="field">
            Rate (INR/kWh)
            <input
              type="number"
              min="0.1"
              max="100"
              step="0.5"
              value={rateText}
              className={rateValid ? "" : "invalid"}
              onChange={(e) => onRate(e.target.value)}
              aria-label="Electricity rate in rupees per kWh"
            />
          </label>
          <div className="status-row">
            {st ? (
              <>
                <Pill tone={st.dataset.available ? "ok" : "bad"}>Dataset {st.dataset.available ? "ready" : "missing"}</Pill>
                <Pill tone={st.model.available ? "ok" : "warn"}>Model {st.model.available ? "trained" : "not trained"}</Pill>
              </>
            ) : (
              <Pill tone={status.error ? "bad" : ""}>{status.error ? "Backend offline" : "Checking..."}</Pill>
            )}
            <button className="btn ghost" onClick={status.reload}>
              Refresh
            </button>
          </div>
        </header>
        {!rateValid && <div className="notice warn">Enter a rate greater than 0 and at most 100 INR/kWh. The last valid rate ({rate}) is still in use.</div>}
        <Async state={status} label="Connecting to the backend...">
          {renderPage}
        </Async>
      </main>
    </div>
  );
}
