# One-time setup: venv, packages, dataset download, preprocessing, model training, frontend packages.
# Run from PowerShell (works even if script execution is restricted):
#   powershell -ExecutionPolicy Bypass -File .\setup.ps1
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$backend = Join-Path $root "backend"
$frontend = Join-Path $root "frontend"
$py = Join-Path $backend ".venv\Scripts\python.exe"

function Step($text) { Write-Host ""; Write-Host "=== $text ===" -ForegroundColor Cyan }
function Check($what) {
    if ($LASTEXITCODE -ne 0) { Write-Host "FAILED: $what (exit code $LASTEXITCODE). See the messages above and README section 5." -ForegroundColor Red; exit 1 }
}

Step "Checking tools"
py -3.12 --version
Check "Python 3.12 not found (install it from python.org, tick 'Add to PATH')"
node --version
Check "Node.js not found (install Node 20 LTS from nodejs.org)"

Set-Location $backend
Step "Creating virtual environment"
if (-not (Test-Path $py)) { py -3.12 -m venv .venv; Check "venv creation" }

Step "Installing Python packages (TensorFlow is large; this can take several minutes)"
& $py -m pip install --upgrade pip
Check "pip upgrade"
& $py -m pip install -r requirements.txt
Check "pip install -r requirements.txt"

Step "Downloading the UCI dataset"
& $py download_dataset.py
Check "dataset download (see README 2.4 for the manual download)"

Step "Preprocessing"
& $py preprocess_data.py
Check "preprocess_data.py"

Step "Training the DNN (prints held-out test MAE and RMSE at the end)"
& $py train_model.py
Check "train_model.py"

Step "Running backend tests"
& $py -m pytest -q
Check "pytest"

Set-Location $frontend
Step "Installing frontend packages"
npm install
Check "npm install"

Write-Host ""
Write-Host "Setup finished. Start the app with:  powershell -ExecutionPolicy Bypass -File .\start.ps1" -ForegroundColor Green
