# DNN-Based Smart Energy Prediction and Optimization System

A software-only project: a TensorFlow/Keras **deep neural network** learns from real historical household electricity data, predicts the next hour and next 24 hours, flags unusual consumption, estimates a bill in rupees and gives data-driven saving tips. A FastAPI backend serves everything to a React (Vite + Recharts) dashboard.

* Dataset: **UCI Individual Household Electric Power Consumption** (real measurements, one French household, Dec 2006 - Nov 2010, 1-minute readings), https://archive.ics.uci.edu/dataset/235
* No hardware, no Docker, no API keys, no paid services.
* Nothing in the dashboard is hard-coded. Until you prepare the dataset and train the model, the app shows setup screens instead of numbers.

> The dataset is historical. "Recent" and "next hour" mean *the period after the last record in the dataset* (late Nov 2010), not today.

---

## 1. Architecture

```
UCI raw file (1-min, kW)
   |  preprocess_data.py : clean, hourly kWh, small gaps interpolated
   v
data/hourly_energy.csv
   |  train_model.py : features -> chronological 70/15/15 split -> scaler (train only) -> Keras DNN
   v
models/energy_dnn.keras, scaler.joblib, metrics.json, test_predictions.csv
   |
   v
FastAPI (main.py + services/)  <---- JSON over HTTP, CORS for localhost:5173 ---->  React dashboard
```

```
DNN-Smart-Energy-Prediction/
  README.md   .gitignore
  backend/
    main.py                  FastAPI app, routes, error handlers, CORS
    config.py                paths and constants
    download_dataset.py      downloads + extracts the UCI file
    preprocess_data.py       raw minutes -> clean hourly kWh
    train_model.py           trains, evaluates, saves the DNN
    requirements.txt  pytest.ini
    data/   models/          generated files (git-ignored)
    services/
      features.py            lag / rolling / calendar features (shared by training and inference)
      data_service.py        dataset loading, summaries
      model_service.py       loads the Keras model, next-hour and 24 h forecasts, metrics
      anomaly_service.py     robust z-score anomaly detection
      bill_service.py        kWh x rate estimation
      recommendation_service.py  rules computed from the data
      errors.py
    tests/                   pytest suite (synthetic data, test-only)
  frontend/
    package.json  vite.config.js  index.html
    src/ App.jsx  main.jsx  pages/  components/  services/api.js  hooks/  utils/  styles/
```

### How the model works

* **Target:** energy (kWh) in hour *T* (mean kW over the hour; hours with fewer than 30 valid minutes are treated as missing; gaps up to 6 h are linearly interpolated, longer gaps stay missing and are never trained on).
* **Features (16):** lags 1, 2, 3, 24, 48, 168 h; rolling mean/std over 24 h and mean over 168 h (computed on past hours only); hour, day-of-week and month as sin/cos; weekend flag. No feature uses hour *T* or later, so there is no target leakage (covered by tests).
* **Split:** chronological 70 % train / 15 % validation / 15 % test. The scaler is fitted on the training part only.
* **Network:** Dense(128, ReLU) - Dropout(0.2) - Dense(64, ReLU) - Dropout(0.1) - Dense(32, ReLU) - Dense(1); Adam, MSE loss, early stopping and learning-rate reduction on validation loss.
* **Metrics:** MAE and RMSE in kWh on the untouched test set, next to three trivial baselines (previous hour, same hour yesterday, training mean) so you can judge whether the DNN is actually useful. A 24 h recursive-forecast score is reported too.
* **24 h forecast:** recursive - each prediction is fed back as the next hour's lag, so error grows with the horizon.

### Anomaly detection (documented limits)

Per (hour-of-day x weekday/weekend) group the **median** and **MAD** are computed (on data before the inspected window). An hour is flagged when `(value - median) / (1.4826 * MAD) > threshold` (default 3.5). A flag means "unusually high for that time", **not** a confirmed fault: holidays, guests, weather, new appliances also trigger it; unusually *low* use is not flagged; seasonal drift is not modelled.

### Bill estimation

`cost = kWh x rate`. The rate (INR/kWh) is set in the top bar (default 8, an adjustable placeholder, not your tariff). It excludes tariff slabs, fixed/demand charges, surcharges and taxes.

---

## Quick start (two commands)

Install Python 3.12 and Node.js 20+, unzip the project, open a PowerShell in the project folder, then:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup.ps1   # once: venv, packages, dataset, preprocessing, training, tests
powershell -ExecutionPolicy Bypass -File .\start.ps1   # every time: starts backend + frontend and opens the browser
```

`setup.ps1` stops with a clear message at the first failing step. The manual, step-by-step version is below (these scripts were not run in my build environment, which has no Windows or internet package access; if one fails, use the manual steps).

## 2. Setup on Windows (PowerShell, VS Code)

Prerequisites: **Python 3.12** (python.org; tick "Add to PATH") and **Node.js 20 LTS or newer** (nodejs.org). TensorFlow 2.18 supports Python 3.9-3.12 - Python 3.13 is *not* supported by this pinned version.

### 2.1 Put the project in a folder

```powershell
New-Item -ItemType Directory -Force C:\Projects | Out-Null
Expand-Archive -Path "$HOME\Downloads\DNN-Smart-Energy-Prediction.zip" -DestinationPath C:\Projects -Force
cd C:\Projects\DNN-Smart-Energy-Prediction
code .
```

(`code .` opens VS Code. Use *Terminal > New Terminal* inside VS Code for the commands below.)

### 2.2 Check versions

```powershell
py -3.12 --version     # expect: Python 3.12.x
node --version         # expect: v20.x or newer
npm --version
```

If `py -3.12` is not found, install Python 3.12 or run `py -0` to list what is installed.

### 2.3 Backend: virtual environment and packages

```powershell
cd C:\Projects\DNN-Smart-Energy-Prediction\backend
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

**If activation is blocked** ("running scripts is disabled on this system"), you do not need to change any policy. Skip `Activate.ps1` and call the venv's Python directly - everything below works with this prefix:

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

(Or, for the current terminal only: `Set-ExecutionPolicy -Scope Process Bypass`.)

Check TensorFlow loads:

```powershell
.\.venv\Scripts\python.exe -c "import tensorflow as tf; print(tf.__version__)"
```
Expected: `2.18.0` (plus possibly harmless oneDNN/CPU messages).

> The package versions in `requirements.txt` were chosen from known TensorFlow 2.18 / Python 3.12 compatibility. If `pip` reports a conflict on your machine, install TensorFlow first (`pip install tensorflow==2.18.0`) and then the rest, or ask for the pins to be adjusted.

### 2.3.1 Run the automated tests first (recommended)

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```
Expected: all tests pass. They use synthetic data (tests only) and a stubbed predictor for API plumbing; the real model is verified by training it on the real dataset (2.5).

### 2.4 Download and prepare the dataset

```powershell
.\.venv\Scripts\python.exe download_dataset.py
.\.venv\Scripts\python.exe preprocess_data.py
```

Expected output of the second command (the format is fixed; the numbers come from your run, roughly 2 million minute rows becoming roughly 35,000 hourly rows from Dec 2006 to Nov 2010):

```
Raw rows:                 <count>
Unparseable timestamps:   <count>
Negative (invalid) kW:    <count>
Missing minute readings:  <count>
Hourly rows:              <count>  (2006-12-16 17:00:00 -> 2010-11-26 21:00:00)
Hours interpolated:       <count>
Hours still missing:      <count>
Saved: ...\backend\data\hourly_energy.csv
```

**If the download fails** (firewall, university network): open https://archive.ics.uci.edu/dataset/235/individual+household+electric+power+consumption , click *Download*, extract `household_power_consumption.txt` into `backend\data\`, then run `preprocess_data.py`. Direct PowerShell alternative:

```powershell
Invoke-WebRequest "https://archive.ics.uci.edu/static/public/235/individual+household+electric+power+consumption.zip" -OutFile data\dataset.zip
Expand-Archive data\dataset.zip -DestinationPath data -Force
```

### 2.5 Train and save the DNN

```powershell
.\.venv\Scripts\python.exe train_model.py
```

Takes a few minutes on a CPU. It prints the split dates, one line per epoch, then:

```
=== Test set (held-out, one-step-ahead) ===
MAE  : <your value> kWh
RMSE : <your value> kWh
Baseline persistence MAE/RMSE : ...
Baseline seasonal-24h MAE/RMSE: ...
24h recursive forecast MAE/RMSE (N origins): ...
Saved: ...\models\energy_dnn.keras ...
```

Your MAE/RMSE are the real results; compare them with the baselines printed beneath. Options: `--epochs 80 --batch-size 256 --seed 7`.

### 2.6 Start the backend

```powershell
cd C:\Projects\DNN-Smart-Energy-Prediction\backend
.\.venv\Scripts\python.exe -m uvicorn main:app --port 8000 --reload
```
Expected: `Uvicorn running on http://127.0.0.1:8000`. Check http://127.0.0.1:8000/api/health and the interactive docs at http://127.0.0.1:8000/docs. The backend picks up a newly trained model/dataset automatically (no restart needed).

### 2.7 Start the frontend (second terminal)

```powershell
cd C:\Projects\DNN-Smart-Energy-Prediction\frontend
npm install
npm run dev
```
Expected: `Local: http://localhost:5173/`. Open that address in your browser.

If the backend runs elsewhere, create `frontend\.env.local` containing `VITE_API_URL=http://127.0.0.1:8000`.

### 2.8 Stop and restart

* Stop a server: click its terminal and press **Ctrl+C**.
* Restart: run the same start command again (2.6 or 2.7) from the right folder.
* If a port is still busy: `Get-NetTCPConnection -LocalPort 8000 | Select OwningProcess` then `Stop-Process -Id <pid>`.

---

## 3. API reference (base `http://127.0.0.1:8000`)

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | liveness + whether dataset/model exist |
| GET | `/api/status` | dataset and model status for the dashboard |
| GET | `/api/dataset/status` | dataset facts |
| GET | `/api/dataset/summary?days=30` | overall + recent-window statistics |
| GET | `/api/energy/history?days=7` | hourly kWh (1-60 days) |
| GET | `/api/energy/daily?days=30` | daily kWh (1-365) |
| GET | `/api/energy/monthly` | monthly kWh with data coverage |
| GET | `/api/predict/next-hour` | DNN prediction for the next hour |
| GET | `/api/predict/forecast?hours=24` | recursive DNN forecast (1-48 h) |
| GET | `/api/model/metrics` | stored MAE/RMSE, split, baselines |
| GET | `/api/model/test-predictions?hours=168` | actual vs predicted on the test set |
| GET | `/api/anomalies?days=30&threshold=3.5` | anomaly detection |
| GET | `/api/bill/estimate?rate=8&source=actual&days=30` | bill (`source` = `actual` or `forecast`) |
| GET | `/api/recommendations?rate=8` | data-driven saving tips |

Examples (shapes are real; the numbers below are placeholders):

```powershell
curl.exe http://127.0.0.1:8000/api/health
# {"status":"ok","version":"1.0.0","dataset_available":true,"model_available":true}

curl.exe "http://127.0.0.1:8000/api/predict/next-hour"
# {"timestamp":"2010-11-26T22:00:00","predicted_kwh":0.0,"based_on_data_until":"2010-11-26T21:00:00","note":"..."}

curl.exe "http://127.0.0.1:8000/api/predict/forecast?hours=24"
# {"hours":24,"method":"...","based_on_data_until":"...","total_kwh":0.0,
#  "predictions":[{"timestamp":"2010-11-26T22:00:00","predicted_kwh":0.0}, ...]}

curl.exe "http://127.0.0.1:8000/api/bill/estimate?rate=9.5&source=actual&days=30"
# {"source":"actual","period":{...},"rate_inr_per_kwh":9.5,"energy_kwh":0.0,"estimated_cost_inr":0.0,
#  "avg_daily_cost_inr":0.0,"projected_30_day_cost_inr":0.0,"valid_hours":0,"disclaimer":"..."}
```

**Errors** always look like `{"error": "...", "hint": "..."}`:

| Situation | Status | Example |
|---|---|---|
| dataset not prepared | 503 | `Hourly dataset not found.` + hint with the commands |
| model not trained | 503 | `Trained model not found.` + hint `python train_model.py` |
| invalid input (`days=0`, `rate=-5`) | 422 | `Invalid input for 'days': ...` |
| unexpected failure | 500 | message + "check the backend terminal" |

---

## 4. Verification checklist and status

Honest status of each acceptance test. "Verified in build" means I ran it in my build environment; **"You must run"** means that environment had no access to PyPI, npm or the UCI server (outbound policy block), so those steps could not be executed and are left for you.

| # | Test | Command / how | Status |
|---|---|---|---|
| 1 | Dependencies install | `pip install -r requirements.txt`, `npm install` | **You must run** |
| 2 | Preprocessing runs | `preprocess_data.py` | Logic verified in build on a tiny synthetic file (missing/invalid minutes, <30-minute hours, interpolation); **you must run it on the real file** |
| 3 | DNN trains and saves | `train_model.py` | **You must run** (needs TensorFlow + dataset). There is no automated training test; the printed metrics and the saved files are the check |
| 4 | Metrics on held-out chronological test set | printed by `train_model.py`, stored in `models/metrics.json` | **You must run**. Split and leakage logic verified in build (feature tests) |
| 5 | FastAPI starts | `uvicorn main:app --port 8000` | **You must run** (FastAPI could not be installed in build) |
| 6 | Health endpoint | `curl.exe http://127.0.0.1:8000/api/health` | **You must run** |
| 7 | Forecast from trained model | `/api/predict/forecast` | Service logic verified in build with a stub predictor (24 hourly points, feedback of predictions, bill/recommendation use); **real-model output you must run** |
| 8 | React app starts | `npm run dev` | **You must run**. In build, all source files compiled and all imports resolved with esbuild (React/Recharts treated as external) |
| 9 | Dashboard shows charts from the API | open http://localhost:5173 | **You must run** |
| 10 | Bill, anomalies, recommendations | Analytics / Anomalies / Recommendations pages | Service logic verified in build on synthetic data (spike detected, few false alarms, cost = kWh x rate, tips built) |
| 11 | No CORS / format errors | browser dev tools (F12) > Network/Console | **You must run**. Response shapes were matched field by field to the frontend code; `tests/test_api.py` includes a CORS header check |
| 12 | README complete | this file | Done |

Backend tests executed in build (14 passed) through a minimal stand-in for pytest: all of `test_features.py` and `test_services.py`. `test_api.py` could not run (needs FastAPI).

### 4.1 Optional extra check after training

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -c "import json; m=json.load(open('models/metrics.json')); print(m['test'], m['baselines_on_test']['seasonal_naive_24h'])"
```

### 4.2 Frontend verification steps

1. `npm run build` completes without errors (creates `frontend\dist`).
2. With only the backend stopped, the page shows "Backend offline" and an error with the start command - not a blank screen.
3. Before training: Overview shows the "model not trained" notice; AI predictions shows the setup guide.
4. After training: Overview shows a next-hour value and a 24 h chart; AI predictions shows forecast, actual-vs-predicted and the metrics table.
5. Change the rate in the top bar (for example 8 to 10): bill figures and the Recommendations text update. Entering `0` or a blank shows a warning and keeps the last valid rate.
6. Anomalies: change window/threshold, press *Run detection*; the table and chart update. Press F12: no red CORS errors.
7. Shrink the browser window below ~880 px: the sidebar becomes a *Menu* button.

---

## 5. Troubleshooting

| Symptom | Fix |
|---|---|
| `py` not recognised | Reinstall Python 3.12 with "Add to PATH" or use `python` if it is 3.12 |
| `Activate.ps1 cannot be loaded` | Use `.\.venv\Scripts\python.exe ...` as shown, or `Set-ExecutionPolicy -Scope Process Bypass` |
| `No matching distribution found for tensorflow` | You are on Python 3.13+ or 32-bit Python. Use Python 3.12 64-bit |
| TensorFlow DLL load failed | Install the Microsoft Visual C++ Redistributable (x64), reopen the terminal |
| `pip` conflicts | Install `tensorflow==2.18.0` first, then `pip install -r requirements.txt` |
| `ERROR: raw dataset not found` | Run `download_dataset.py` or place the file in `backend\data\` (name must be `household_power_consumption.txt`) |
| Download blocked | Manual download steps in 2.4 |
| `Trained model not found` in the UI | Run `train_model.py`, then press *Refresh* in the dashboard |
| Could not load the trained model | Delete `backend\models\*` and retrain with the installed TensorFlow version |
| Dashboard says "Cannot reach the backend API" | Start uvicorn (2.6); check http://127.0.0.1:8000/api/health in the browser |
| CORS error in the browser console | Open the app at `http://localhost:5173` (or `127.0.0.1:5173`); other ports are not allowed in `main.py` |
| `Port 5173 is already in use` | Close the other Vite terminal (Ctrl+C); `strictPort` is on so the CORS origin stays valid |
| `npm install` fails | Check `node --version` is 20+, delete `frontend\node_modules`, run again; behind a proxy set `npm config set proxy ...` |
| Charts empty | Dataset window ends in Nov 2010 by design; check `/api/status` |

## 6. Limitations (please read)

* One household, one dataset; results do not generalise to other homes or tariffs.
* Forecasts start after the last record of a 2010 dataset; this is an offline analysis tool, not live monitoring.
* The 24 h forecast is recursive and degrades with horizon; check the 24 h metric and baselines in the dashboard.
* Savings in rupees are never promised; recommendations show evidence and cost-of-pattern figures only.
* Bill estimates are flat-rate and exclude slabs, fixed charges and taxes.
* Dependency versions were not installable in my build environment; see the status table.

Dataset credit: Hebrail, G. & Berard, A. (2006). Individual Household Electric Power Consumption. UCI Machine Learning Repository, CC BY 4.0.
