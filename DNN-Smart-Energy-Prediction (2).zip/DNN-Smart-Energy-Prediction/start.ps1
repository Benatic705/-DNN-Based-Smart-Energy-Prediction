# Starts the FastAPI backend (port 8000) and the React dev server (port 5173) in two windows,
# then opens the dashboard. Close each window (or press Ctrl+C in it) to stop a server.
#   powershell -ExecutionPolicy Bypass -File .\start.ps1
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$py = Join-Path $root "backend\.venv\Scripts\python.exe"
if (-not (Test-Path $py)) {
    Write-Host "Virtual environment not found. Run setup.ps1 first." -ForegroundColor Red
    exit 1
}

$backendCmd = "Set-Location '$root\backend'; & '$py' -m uvicorn main:app --port 8000 --reload"
$frontendCmd = "Set-Location '$root\frontend'; if (-not (Test-Path node_modules)) { npm install }; npm run dev"

Start-Process powershell -ArgumentList "-NoExit", "-Command", $backendCmd
Start-Process powershell -ArgumentList "-NoExit", "-Command", $frontendCmd

Write-Host "Starting servers... opening http://localhost:5173 in a few seconds."
Start-Sleep -Seconds 8
Start-Process "http://localhost:5173"
